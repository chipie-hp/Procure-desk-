import { useState, useMemo, useRef, useEffect, useCallback } from "react";
import { createClient } from "@supabase/supabase-js";

// ─── Supabase client ─────────────────────────────────────────────────────────
// Replace these two values with your own from:
// Supabase Dashboard → Settings → API
const SUPABASE_URL  = "https://ugxozcwzgsxmvztdcaph.supabase.co";
const SUPABASE_ANON = "sb_publishable_O3aIpRAKd5GYc68fKb7YRw_T9LYiflW";
const supabase = createClient(SUPABASE_URL, SUPABASE_ANON);

/* ── Fonts & Reset ──────────────────────────────────────────────────────── */
const GS = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Sora', sans-serif; background: #0a1628; color: #c8ddf0; }
    input, select, textarea, button { font-family: inherit; }
    ::-webkit-scrollbar { width: 5px; height: 5px; }
    ::-webkit-scrollbar-track { background: #0a1628; }
    ::-webkit-scrollbar-thumb { background: #1e3350; border-radius: 99px; }
    @keyframes fadeUp { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:translateY(0); } }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
    .fade-up { animation: fadeUp 0.3s ease both; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .spin { animation: spin 0.8s linear infinite; }
  `}</style>
);

/* ── Design Tokens ──────────────────────────────────────────────────────── */
const T = {
  teal: "#0fb8a4",
  tealDim: "#0d9489",
  tealGlow: "rgba(15,184,164,0.18)",
  tealMuted: "rgba(15,184,164,0.08)",
  purple: "#7b5ea7",
  purpleGlow: "rgba(123,94,167,0.2)",
  amber: "#f5a623",
  red: "#e05c5c",
  green: "#3ecf8e",
  sidebar: "#07111f",
  sideHov: "#0d1e30",
  mainBg: "#0a1628",
  cardBg: "#0d1e30",
  cardBg2: "#0f2236",
  border: "#162840",
  border2: "#1c3250",
  t1: "#e2eff8",
  t2: "#7a9dba",
  t3: "#3a5a78",
  mono: "'JetBrains Mono', monospace",
};

/* ── Sample Data ────────────────────────────────────────────────────────── */
const INITIAL_PURCHASES = [
  { id:1, vendor:"FreshMart", item:"Rice (5kg)", qty:10, price:8.50, category:"Foods", date:"2025-02-10" },
  { id:2, vendor:"FreshMart", item:"Cooking Oil (2L)", qty:5, price:4.20, category:"Foods", date:"2025-02-11" },
  { id:3, vendor:"CleanCo", item:"Floor Cleaner", qty:8, price:3.75, category:"Cleaning", date:"2025-02-12" },
  { id:4, vendor:"DrinkHub", item:"Orange Juice (1L)", qty:12, price:2.90, category:"Beverages", date:"2025-02-13" },
  { id:5, vendor:"CleanCo", item:"Dish Soap", qty:6, price:2.10, category:"Cleaning", date:"2025-02-14" },
  { id:6, vendor:"DrinkHub", item:"Mineral Water (500ml)", qty:24, price:0.85, category:"Beverages", date:"2025-02-15" },
  { id:7, vendor:"OfficeWorld", item:"A4 Paper (Ream)", qty:10, price:5.60, category:"Stationery", date:"2025-02-16" },
  { id:8, vendor:"OfficeWorld", item:"Ballpoint Pens (Box)", qty:4, price:3.20, category:"Stationery", date:"2025-02-17" },
  { id:9, vendor:"FreshMart", item:"Sugar (2kg)", qty:8, price:2.40, category:"Foods", date:"2025-02-18" },
  { id:10, vendor:"DrinkHub", item:"Green Tea (Box)", qty:6, price:4.50, category:"Beverages", date:"2025-02-19" },
];

const INITIAL_VENDORS = [
  { id:1, name:"FreshMart", category:"Foods & Grocery", contact:"freshmart@example.com", phone:"+265 999 001", address:"Market Square, Lilongwe" },
  { id:2, name:"CleanCo", category:"Cleaning Supplies", contact:"cleanc@example.com", phone:"+265 999 002", address:"Industrial Area, Blantyre" },
  { id:3, name:"DrinkHub", category:"Beverages", contact:"hub@drinkh.com", phone:"+265 999 003", address:"City Mall, Lilongwe" },
  { id:4, name:"OfficeWorld", category:"Stationery", contact:"info@officeworld.mw", phone:"+265 999 004", address:"Area 3, Lilongwe" },
];

const CATEGORIES = ["Foods","Beverages","Cleaning","Stationery","Electronics","Other"];
const CAT_ICON = { Foods:"🍽️", Beverages:"🧃", Cleaning:"🧹", Stationery:"📎", Electronics:"⚡", Other:"📦" };
const COLORS = [T.teal, T.purple, T.amber, T.green, "#6366f1", "#f43f5e", "#fb923c"];

/* ── Helpers ────────────────────────────────────────────────────────────── */
const fmt = n => `Mwk ${Number(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const fmtK = n => n>=1000 ? `Mwk ${(n/1000).toFixed(1)}k` : `Mwk ${Number(n).toFixed(2)}`;
const today = () => new Date().toISOString().slice(0,10);
const uid = () => Date.now() + Math.random();
const capFirst = s => s.replace(/(^|\s)\S/g, c => c.toUpperCase());

/* ── Primitive UI ───────────────────────────────────────────────────────── */
function Card({ children, s={}, className="" }) {
  return <div className={className} style={{ background:T.cardBg, border:`1px solid ${T.border}`, borderRadius:16, padding:22, ...s }}>{children}</div>;
}

function Badge({ children, color=T.teal, s={} }) {
  return <span style={{ background:`${color}1a`, color, borderRadius:99, padding:"3px 10px", fontSize:11, fontWeight:600, border:`1px solid ${color}30`, whiteSpace:"nowrap", ...s }}>{children}</span>;
}

function Btn({ children, onClick, v="primary", s={}, disabled=false }) {
  const [h,setH]=useState(false);
  const base = { border:"none", borderRadius:10, padding:"9px 18px", fontSize:13, fontWeight:600, cursor:disabled?"not-allowed":"pointer", transition:"all 0.15s", display:"inline-flex", alignItems:"center", gap:7, opacity:disabled?0.5:1, ...s };
  const vs = {
    primary:{ background:h&&!disabled?T.tealDim:T.teal, color:"#fff", boxShadow:h&&!disabled?`0 4px 20px ${T.tealGlow}`:"none" },
    ghost:{ background:h&&!disabled?"#0d1e30":"transparent", color:T.t2, border:`1px solid ${h?"#1c3250":"transparent"}` },
    outline:{ background:h&&!disabled?"#0d1e30":"transparent", color:T.t1, border:`1px solid ${T.border2}` },
    purple:{ background:h&&!disabled?"#6b4e97":T.purple, color:"#fff" },
    danger:{ background:h&&!disabled?"#c04040":T.red, color:"#fff" },
    amber:{ background:h&&!disabled?"#d4901e":T.amber, color:"#fff" },
  };
  return <button style={{...base,...vs[v]}} onClick={disabled?undefined:onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}>{children}</button>;
}

function Input({ label, value, onChange, type="text", placeholder="", s={}, onBlur, onFocus, readOnly }) {
  const [f,setF]=useState(false);
  return (
    <div style={{display:"flex",flexDirection:"column",gap:5,...s}}>
      {label&&<label style={{fontSize:10,fontWeight:700,color:T.t2,textTransform:"uppercase",letterSpacing:"0.1em"}}>{label}</label>}
      <input type={type} value={value} placeholder={placeholder} readOnly={readOnly}
        onChange={e=>onChange&&onChange(e.target.value)}
        onFocus={()=>{setF(true);onFocus&&onFocus();}}
        onBlur={()=>{setF(false);onBlur&&onBlur();}}
        style={{ background:"#070f1c", border:`1.5px solid ${f?T.teal:T.border}`, borderRadius:9, padding:"10px 13px", color:T.t1, fontSize:13, outline:"none", transition:"all 0.2s", boxShadow:f?`0 0 0 3px ${T.tealGlow}`:"none", width:"100%", cursor:readOnly?"default":"text" }}/>
    </div>
  );
}

function Select({ label, value, onChange, opts }) {
  const [f,setF]=useState(false);
  return (
    <div style={{display:"flex",flexDirection:"column",gap:5}}>
      {label&&<label style={{fontSize:10,fontWeight:700,color:T.t2,textTransform:"uppercase",letterSpacing:"0.1em"}}>{label}</label>}
      <select value={value} onChange={e=>onChange(e.target.value)} onFocus={()=>setF(true)} onBlur={()=>setF(false)}
        style={{ background:"#070f1c", border:`1.5px solid ${f?T.teal:T.border}`, borderRadius:9, padding:"10px 13px", color:T.t1, fontSize:13, outline:"none", width:"100%", cursor:"pointer", boxShadow:f?`0 0 0 3px ${T.tealGlow}`:"none" }}>
        {opts.map(o=><option key={o} value={o} style={{background:"#070f1c"}}>{o}</option>)}
      </select>
    </div>
  );
}

function Th({ children, right }) {
  return <th style={{ padding:"10px 14px", textAlign:right?"right":"left", background:"#070f1c", color:T.t3, fontWeight:700, fontSize:10, textTransform:"uppercase", letterSpacing:"0.1em", borderBottom:`1px solid ${T.border}`, whiteSpace:"nowrap" }}>{children}</th>;
}
function Td({ children, right, mono, bold, color }) {
  return <td style={{ padding:"10px 14px", textAlign:right?"right":"left", color:color||(bold?T.t1:T.t2), fontWeight:bold?600:400, fontFamily:mono?T.mono:undefined, fontSize:mono?12:13, borderBottom:`1px solid ${T.border}` }}>{children}</td>;
}

/* ── Modal ──────────────────────────────────────────────────────────────── */
function Modal({ open, onClose, title, children, width=500 }) {
  if (!open) return null;
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.7)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center", backdropFilter:"blur(4px)" }} onClick={onClose}>
      <div className="fade-up" style={{ background:T.cardBg, border:`1px solid ${T.border2}`, borderRadius:18, padding:28, width, maxWidth:"95vw", maxHeight:"90vh", overflowY:"auto" }} onClick={e=>e.stopPropagation()}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:22 }}>
          <div style={{ fontSize:16, fontWeight:700, color:T.t1 }}>{title}</div>
          <button onClick={onClose} style={{ background:"none", border:"none", color:T.t3, cursor:"pointer", fontSize:20, lineHeight:1 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ── Charts ─────────────────────────────────────────────────────────────── */
function Donut({ data, total, size=130 }) {
  const cx=size/2, cy=size/2, r=size*0.37, sw=size*0.13;
  const circ = 2*Math.PI*r;
  let off=0;
  const slices = data.map((d,i)=>{
    const pct = total>0 ? d.value/total : 0;
    const dash = pct*circ;
    const s = { off, dash, gap:circ-dash, color:COLORS[i%COLORS.length], label:d.label, pct };
    off+=dash; return s;
  });
  return (
    <div style={{display:"flex",alignItems:"center",gap:18}}>
      <svg width={size} height={size} style={{transform:"rotate(-90deg)",flexShrink:0}}>
        <circle cx={cx} cy={cy} r={r} fill="none" stroke="#0d1e30" strokeWidth={sw}/>
        {slices.map((s,i)=>(
          <circle key={i} cx={cx} cy={cy} r={r} fill="none" stroke={s.color} strokeWidth={sw}
            strokeDasharray={`${s.dash} ${s.gap}`} strokeDashoffset={-s.off}/>
        ))}
      </svg>
      <div style={{display:"flex",flexDirection:"column",gap:6}}>
        {slices.map((s,i)=>(
          <div key={i} style={{display:"flex",alignItems:"center",gap:8}}>
            <span style={{width:7,height:7,borderRadius:"50%",background:s.color,flexShrink:0}}/>
            <span style={{fontSize:11,color:T.t2,flex:1}}>{s.label}</span>
            <span style={{fontSize:11,fontWeight:700,color:T.t1,fontFamily:T.mono}}>{(s.pct*100).toFixed(0)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ProgBar({ label, value, max, color, sub }) {
  const pct = max>0?(value/max)*100:0;
  return (
    <div style={{marginBottom:14}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
        <span style={{fontSize:13,color:T.t1,fontWeight:500}}>{label}</span>
        <div style={{display:"flex",gap:8,alignItems:"center"}}>
          {sub&&<span style={{fontSize:11,color:T.t3}}>{sub}</span>}
          <span style={{fontSize:12,fontWeight:700,color:T.t1,fontFamily:T.mono}}>{fmtK(value)}</span>
        </div>
      </div>
      <div style={{height:7,borderRadius:99,background:"#0a1628"}}>
        <div style={{height:"100%",width:`${pct}%`,background:`linear-gradient(90deg,${color},${color}99)`,borderRadius:99,transition:"width 0.8s ease"}}/>
      </div>
    </div>
  );
}

/* ── Nav Item ───────────────────────────────────────────────────────────── */
function NavItem({ icon, label, active, onClick, badge }) {
  const [h,setH]=useState(false);
  return (
    <div onClick={onClick} onMouseEnter={()=>setH(true)} onMouseLeave={()=>setH(false)}
      style={{ display:"flex", alignItems:"center", gap:10, padding:"9px 14px", borderRadius:9, cursor:"pointer",
        background: active?"#0d1e30":h?"#0a1828":"transparent",
        borderLeft:`2.5px solid ${active?T.teal:"transparent"}`,
        color: active?T.t1:T.t2, fontSize:13, fontWeight:active?600:400,
        transition:"all 0.15s", userSelect:"none", position:"relative" }}>
      <span style={{fontSize:15,flexShrink:0}}>{icon}</span>
      <span style={{flex:1}}>{label}</span>
      {badge&&<span style={{background:T.teal,color:"#fff",borderRadius:99,fontSize:10,fontWeight:700,padding:"1px 7px"}}>{badge}</span>}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAGE: HOME / DASHBOARD
══════════════════════════════════════════════════════════════════════════ */
function Home({ purchases, vendors, go, openNewPurchase, openAddVendor }) {
  const total = purchases.reduce((s,p)=>s+p.qty*p.price, 0);
  const totalQty = purchases.reduce((s,p)=>s+p.qty, 0);
  const uniqueItems = new Set(purchases.map(p=>p.item)).size;

  const byVendor = useMemo(()=>{
    const m={};
    purchases.forEach(p=>{ m[p.vendor]=(m[p.vendor]||0)+p.qty*p.price; });
    return Object.entries(m).sort((a,b)=>b[1]-a[1]);
  },[purchases]);

  const byCategory = useMemo(()=>{
    const m={};
    purchases.forEach(p=>{ m[p.category]=(m[p.category]||0)+p.qty*p.price; });
    return Object.entries(m).sort((a,b)=>b[1]-a[1]).map(([label,value])=>({label,value}));
  },[purchases]);

  const recentMonth = useMemo(()=>{
    const grouped={};
    purchases.forEach(p=>{
      const key=p.date.slice(0,7);
      grouped[key]=(grouped[key]||0)+p.qty*p.price;
    });
    return Object.entries(grouped).sort().slice(-6);
  },[purchases]);

  const maxMonth = Math.max(...recentMonth.map(r=>r[1]),1);

  return (
    <div className="fade-up">
      <div style={{marginBottom:26}}>
        <h1 style={{fontSize:22,fontWeight:800,color:T.t1,letterSpacing:"-0.02em"}}>Home</h1>
        <p style={{fontSize:13,color:T.t2,marginTop:3}}>Welcome back, Jane! Here's your procurement command center.</p>
      </div>

      {/* Big metric cards */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:14,marginBottom:20}}>
        {[
          { label:"Total Spend", value:fmt(total), sub:`${purchases.length} transactions`, color:T.teal, icon:"💰" },
          { label:"Vendors", value:vendors.length, sub:`${new Set(purchases.map(p=>p.vendor)).size} active`, color:T.purple, icon:"🏭" },
          { label:"Unique Items", value:uniqueItems, sub:`${totalQty} total units`, color:T.amber, icon:"📦" },
          { label:"Categories", value:byCategory.length, sub:"product groups", color:T.green, icon:"🗂️" },
        ].map(c=>(
          <Card key={c.label} s={{borderTop:`2.5px solid ${c.color}`,position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",top:14,right:16,fontSize:22,opacity:0.15}}>{c.icon}</div>
            <div style={{fontSize:10,fontWeight:700,color:c.color,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:10}}>{c.label}</div>
            <div style={{fontSize:26,fontWeight:800,color:T.t1,fontFamily:T.mono,letterSpacing:"-0.03em"}}>{c.value}</div>
            <div style={{fontSize:11,color:T.t3,marginTop:5}}>{c.sub}</div>
          </Card>
        ))}
      </div>

      {/* Quick Actions */}
      <Card s={{marginBottom:20,padding:"16px 20px"}}>
        <div style={{fontSize:11,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:12}}>Quick Actions</div>
        <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
          <Btn onClick={openNewPurchase}>＋ New Purchase</Btn>
          <Btn v="outline" onClick={openAddVendor}>🏭 Add Vendor</Btn>
          <Btn v="outline" onClick={()=>go("catalog")}>📖 View Catalog</Btn>
          <Btn v="outline" onClick={()=>go("insights")}>📊 Insights</Btn>
          <Btn v="purple" onClick={()=>go("reports")}>📋 Generate Report</Btn>
        </div>
      </Card>

      {/* Bottom two-col */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        {/* Recent Purchases */}
        <Card>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
            <div style={{fontSize:14,fontWeight:700,color:T.t1}}>Recent Purchases</div>
            <Btn v="ghost" s={{fontSize:11,padding:"4px 10px"}} onClick={()=>go("purchases")}>View all →</Btn>
          </div>
          {purchases.length===0
            ? <div style={{textAlign:"center",padding:"32px 0",color:T.t3,fontSize:13}}>No purchases yet.</div>
            : <table style={{width:"100%",borderCollapse:"collapse"}}>
                <thead><tr><Th>Item</Th><Th>Vendor</Th><Th right>Amount</Th></tr></thead>
                <tbody>{purchases.slice(0,7).map(p=>(
                  <tr key={p.id} onMouseEnter={e=>e.currentTarget.style.background="#0f2236"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                    <Td bold>{p.item}</Td>
                    <Td><Badge color={T.teal}>{p.vendor}</Badge></Td>
                    <Td right mono bold color={T.teal}>{fmtK(p.qty*p.price)}</Td>
                  </tr>
                ))}</tbody>
              </table>
          }
        </Card>

        {/* Monthly Spending Overview */}
        <Card>
          <div style={{fontSize:14,fontWeight:700,color:T.t1,marginBottom:4}}>Monthly Spending Overview</div>
          <div style={{fontSize:11,color:T.t2,marginBottom:18}}>Spend trend by month</div>
          {recentMonth.length===0
            ? <div style={{textAlign:"center",padding:"32px 0",color:T.t3,fontSize:13}}>No data yet.</div>
            : <>
                <div style={{display:"flex",alignItems:"flex-end",gap:6,height:100,marginBottom:12}}>
                  {recentMonth.map(([month,val])=>(
                    <div key={month} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
                      <div style={{width:"100%",background:`linear-gradient(180deg,${T.teal},${T.tealDim})`,borderRadius:"5px 5px 0 0",height:`${(val/maxMonth)*90}px`,minHeight:4,transition:"height 0.7s ease"}}/>
                      <div style={{fontSize:9,color:T.t3,textAlign:"center"}}>{month.slice(5)}</div>
                    </div>
                  ))}
                </div>
                <div style={{paddingTop:14,borderTop:`1px solid ${T.border}`}}>
                  <Donut data={byCategory} total={total} size={120}/>
                </div>
              </>
          }
        </Card>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAGE: PURCHASES
══════════════════════════════════════════════════════════════════════════ */
function Purchases({ purchases, setPurchases, vendors, modalOpen, setModalOpen, addPurchaseDB, deletePurchaseDB }) {
  const [search,    setSearch]   = useState("");
  const [groupBy,   setGroupBy]  = useState("none"); // "none" | vendor name
  const [collapsed, setCollapsed]= useState({});     // { vendorName: bool }
  const [form,      setForm]     = useState({ vendor:"", item:"", qty:"", price:"", category:"Foods", date:today() });
  const [sugs,      setSugs]     = useState([]);
  const [showSugs,  setShowSugs] = useState(false);
  const [flash,     setFlash]    = useState("");
  const [delId,     setDelId]    = useState(null);

  /* ── item autofill history ── */
  const history = useMemo(()=>{
    const m={};
    purchases.forEach(p=>{ m[p.item.toLowerCase()]={ price:p.price, category:p.category, item:p.item, vendor:p.vendor }; });
    return m;
  },[purchases]);

  /* ── vendor list for dropdown ── */
  const vendorNames = useMemo(()=>["none",...new Set(purchases.map(p=>p.vendor)).values()],[purchases]);

  /* ── filtered rows ── */
  const filtered = useMemo(()=>{
    let rows = purchases;
    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(p=>
        p.item.toLowerCase().includes(q) ||
        p.vendor.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q)
      );
    }
    // if groupBy is a specific vendor name, filter to that vendor only
    if (groupBy !== "none") rows = rows.filter(p=>p.vendor === groupBy);
    return rows;
  },[purchases, search, groupBy]);

  /* ── grouped structure ── */
  const groups = useMemo(()=>{
    if (groupBy === "none") return null;
    const map = {};
    filtered.forEach(p=>{
      if (!map[p.vendor]) map[p.vendor] = [];
      map[p.vendor].push(p);
    });
    return Object.entries(map).sort((a,b)=>a[0].localeCompare(b[0]));
  },[filtered, groupBy]);

  const toggleCollapse = v => setCollapsed(c=>({...c,[v]:!c[v]}));

  /* ── item input handler ── */
  const onItem = v => {
    setForm(f=>({...f,item:capFirst(v)}));
    if (v.length>0) {
      const s=Object.values(history).filter(h=>h.item.toLowerCase().includes(v.toLowerCase()));
      setSugs(s); setShowSugs(s.length>0);
    } else setShowSugs(false);
  };

  /* ── add purchase (local + optional DB) ── */
  const addPurchase = async () => {
    if (!form.vendor||!form.item||!form.qty||!form.price) { setFlash("error"); setTimeout(()=>setFlash(""),2000); return; }
    const p = { ...form, qty:+form.qty, price:+form.price };
    if (addPurchaseDB) {
      const err = await addPurchaseDB(p); // DB handles state update
      if (err) { setFlash("error"); setTimeout(()=>setFlash(""),2000); return; }
    } else {
      setPurchases(prev=>[{ id:uid(), ...p }, ...prev]);
    }
    setForm(f=>({ vendor:f.vendor, item:"", qty:"", price:"", category:f.category, date:today() }));
    setFlash("success"); setTimeout(()=>setFlash(""),2000);
  };

  const deletePurchase = async (id) => {
    if (deletePurchaseDB) await deletePurchaseDB(id); // handles state update
    else setPurchases(p=>p.filter(x=>x.id!==id));
    setDelId(null);
  };

  /* ── vendor stats for group header ── */
  const vendorStats = useMemo(()=>{
    const m={};
    purchases.forEach(p=>{
      if(!m[p.vendor]) m[p.vendor]={spend:0,items:new Set(),count:0};
      m[p.vendor].spend += p.qty*p.price;
      m[p.vendor].items.add(p.item);
      m[p.vendor].count++;
    });
    return m;
  },[purchases]);

  /* ── shared table body rows renderer ── */
  const PurchaseRow = ({ p }) => (
    <tr onMouseEnter={e=>e.currentTarget.style.background="#0f2236"}
        onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
      <Td><span style={{fontFamily:T.mono,fontSize:11}}>{p.date}</span></Td>
      <Td bold>{p.item}</Td>
      {groupBy==="none" && <Td><Badge color={T.teal}>{p.vendor}</Badge></Td>}
      <Td><Badge color={T.purple}>{p.category}</Badge></Td>
      <Td right mono>{p.qty}</Td>
      <Td right mono>{fmt(p.price)}</Td>
      <Td right mono bold color={T.teal}>{fmt(p.qty*p.price)}</Td>
      <td style={{padding:"8px 14px",borderBottom:`1px solid ${T.border}`}}>
        <Btn v="ghost" s={{padding:"4px 8px",fontSize:11}} onClick={()=>setDelId(p.id)}>🗑</Btn>
      </td>
    </tr>
  );

  const colCount = groupBy==="none" ? 8 : 7;

  return (
    <div className="fade-up">
      <div style={{marginBottom:22}}>
        <h1 style={{fontSize:22,fontWeight:800,color:T.t1,letterSpacing:"-0.02em"}}>Purchases</h1>
        <p style={{fontSize:13,color:T.t2,marginTop:3}}>Full ledger of all procurement transactions</p>
      </div>

      {/* Toolbar */}
      <div style={{display:"flex",gap:10,marginBottom:16,alignItems:"center",flexWrap:"wrap"}}>
        {/* Search */}
        <div style={{flex:"1 1 220px",position:"relative"}}>
          <span style={{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",fontSize:13,color:T.t3,pointerEvents:"none"}}>🔍</span>
          <input value={search} onChange={e=>setSearch(e.target.value)}
            placeholder="Search item, vendor, or category…"
            style={{ background:"#070f1c", border:`1.5px solid ${search?T.teal:T.border}`, borderRadius:10,
              padding:"10px 13px 10px 34px", color:T.t1, fontSize:13, outline:"none", width:"100%",
              transition:"border-color 0.2s",
              boxShadow: search ? `0 0 0 3px ${T.tealGlow}` : "none" }}
            onFocus={e=>{ e.target.style.borderColor=T.teal; e.target.style.boxShadow=`0 0 0 3px ${T.tealGlow}`; }}
            onBlur={e=>{ e.target.style.borderColor=search?T.teal:T.border; e.target.style.boxShadow=search?`0 0 0 3px ${T.tealGlow}`:"none"; }}/>
        </div>

        {/* Group-by dropdown */}
        <div style={{display:"flex",alignItems:"center",gap:8,flexShrink:0}}>
          <label style={{fontSize:11,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.09em",whiteSpace:"nowrap"}}>
            Group by
          </label>
          <select value={groupBy} onChange={e=>{ setGroupBy(e.target.value); setCollapsed({}); }}
            style={{ background:"#070f1c",
              border:`1.5px solid ${groupBy!=="none" ? T.teal : T.border}`,
              borderRadius:9, padding:"9px 13px", color: groupBy!=="none" ? T.teal : T.t1,
              fontSize:13, fontFamily:"inherit", fontWeight: groupBy!=="none"?600:400,
              outline:"none", cursor:"pointer", minWidth:160,
              boxShadow: groupBy!=="none" ? `0 0 0 3px ${T.tealGlow}` : "none",
              transition:"all 0.2s" }}>
            <option value="none" style={{background:"#070f1c",color:T.t1}}>No grouping</option>
            <optgroup label="── By Vendor ──" style={{color:T.t3}}>
              {vendorNames.filter(v=>v!=="none").map(v=>(
                <option key={v} value={v} style={{background:"#070f1c",color:T.t1}}>{v}</option>
              ))}
            </optgroup>
          </select>
          {groupBy!=="none" && (
            <Btn v="ghost" s={{padding:"7px 10px",fontSize:11}} onClick={()=>{ setGroupBy("none"); setCollapsed({}); }}>✕</Btn>
          )}
        </div>

        <Btn onClick={()=>setModalOpen(true)} s={{flexShrink:0}}>＋ New Purchase</Btn>
      </div>

      {/* Summary strip when a vendor is selected */}
      {groupBy !== "none" && vendorStats[groupBy] && (
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:14}}>
          {[
            { l:"Total Spend",   v:fmt(vendorStats[groupBy].spend),        c:T.teal   },
            { l:"Transactions",  v:vendorStats[groupBy].count,              c:T.purple },
            { l:"Unique Items",  v:vendorStats[groupBy].items.size,         c:T.amber  },
          ].map(x=>(
            <Card key={x.l} s={{padding:"12px 16px",borderTop:`2px solid ${x.c}`}}>
              <div style={{fontSize:10,fontWeight:700,color:x.c,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:5}}>{x.l}</div>
              <div style={{fontSize:18,fontWeight:800,color:T.t1,fontFamily:T.mono}}>{x.v}</div>
            </Card>
          ))}
        </div>
      )}

      {/* ── FLAT TABLE (no grouping) ── */}
      {groupBy === "none" && (
        <Card s={{padding:0,overflow:"hidden"}}>
          <div style={{padding:"12px 18px",borderBottom:`1px solid ${T.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{fontSize:13,fontWeight:700,color:T.t1}}>All Purchases</span>
            <Badge color={T.teal}>{filtered.length} records</Badge>
          </div>
          <div style={{overflowX:"auto",maxHeight:540,overflowY:"auto"}}>
            <table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
              <thead style={{position:"sticky",top:0,zIndex:2}}>
                <tr><Th>Date</Th><Th>Item</Th><Th>Vendor</Th><Th>Category</Th><Th right>Qty</Th><Th right>Unit Price</Th><Th right>Total</Th><Th></Th></tr>
              </thead>
              <tbody>
                {filtered.length===0
                  ? <tr><td colSpan={8} style={{padding:"40px",textAlign:"center",color:T.t3}}>No results found.</td></tr>
                  : filtered.map(p=><PurchaseRow key={p.id} p={p}/>)
                }
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* ── GROUPED VIEW ── */}
      {groupBy !== "none" && (
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {filtered.length === 0 ? (
            <Card s={{textAlign:"center",padding:"48px",color:T.t3}}>No purchases found for <strong style={{color:T.t2}}>{groupBy}</strong>.</Card>
          ) : (
            <Card s={{padding:0,overflow:"hidden"}}>
              {/* Vendor header bar */}
              <div style={{
                padding:"14px 18px",
                background:`linear-gradient(90deg,${T.teal}12,transparent)`,
                borderBottom:`1px solid ${T.border}`,
                display:"flex", alignItems:"center", gap:14,
              }}>
                <div style={{width:38,height:38,borderRadius:10,background:`linear-gradient(135deg,${T.teal},${T.purple})`,
                  display:"flex",alignItems:"center",justifyContent:"center",fontSize:16,fontWeight:800,color:"#fff",flexShrink:0}}>
                  {groupBy[0]}
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:700,color:T.t1}}>{groupBy}</div>
                  <div style={{fontSize:11,color:T.t2,marginTop:1}}>
                    {filtered.length} transaction{filtered.length!==1?"s":""}
                    &nbsp;·&nbsp;
                    {new Set(filtered.map(p=>p.item)).size} unique items
                  </div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:11,color:T.t3,marginBottom:2}}>Total Spend</div>
                  <div style={{fontSize:16,fontWeight:800,color:T.teal,fontFamily:T.mono}}>
                    {fmt(filtered.reduce((s,p)=>s+p.qty*p.price,0))}
                  </div>
                </div>
              </div>

              <div style={{overflowX:"auto",maxHeight:560,overflowY:"auto"}}>
                <table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
                  <thead style={{position:"sticky",top:0,zIndex:2}}>
                    <tr><Th>Date</Th><Th>Item</Th><Th>Category</Th><Th right>Qty</Th><Th right>Unit Price</Th><Th right>Total</Th><Th></Th></tr>
                  </thead>
                  <tbody>
                    {filtered.map(p=><PurchaseRow key={p.id} p={p}/>)}
                    {/* Subtotal row */}
                    <tr style={{background:"#070f1c"}}>
                      <td colSpan={5} style={{padding:"11px 14px",textAlign:"right",fontWeight:700,color:T.t2,fontSize:12}}>Subtotal</td>
                      <td style={{padding:"11px 14px",textAlign:"right",fontWeight:800,color:T.teal,fontFamily:T.mono,fontSize:14}}>
                        {fmt(filtered.reduce((s,p)=>s+p.qty*p.price,0))}
                      </td>
                      <td style={{padding:"11px 14px"}}/>
                    </tr>
                  </tbody>
                </table>
              </div>
            </Card>
          )}
        </div>
      )}

      {/* New Purchase Modal */}
      <Modal open={modalOpen} onClose={()=>{setModalOpen(false);setFlash("");}} title="New Purchase Entry" width={520}>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Select label="Vendor" value={form.vendor||""} onChange={v=>setForm(f=>({...f,vendor:v}))}
              opts={["", ...vendors.map(v=>v.name),...(form.vendor&&!vendors.find(v=>v.name===form.vendor)?[form.vendor]:[])]}/>
            <Input label="Date" value={form.date} onChange={v=>setForm(f=>({...f,date:v}))} type="date"/>
          </div>
          <div style={{position:"relative"}}>
            <Input label="Item" value={form.item} onChange={onItem} placeholder="e.g. Rice (5kg)"
              onBlur={()=>setTimeout(()=>setShowSugs(false),160)}/>
            {showSugs&&(
              <div style={{position:"absolute",top:"100%",left:0,right:0,zIndex:50,background:T.cardBg,borderRadius:10,
                boxShadow:"0 8px 32px rgba(0,0,0,0.5)",border:`1px solid ${T.border2}`,overflow:"hidden",marginTop:4}}>
                {sugs.map((s,i)=>(
                  <div key={i} onClick={()=>{setForm(f=>({...f,item:s.item,price:s.price,category:s.category,vendor:s.vendor}));setShowSugs(false);}}
                    style={{padding:"10px 14px",cursor:"pointer",fontSize:12,borderBottom:`1px solid ${T.border}`,
                      display:"flex",justifyContent:"space-between",color:T.t1}}
                    onMouseEnter={e=>e.currentTarget.style.background="#0f2236"}
                    onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                    <span>{s.item}</span>
                    <div style={{display:"flex",gap:8}}>
                      <Badge color={T.purple}>{s.category}</Badge>
                      <span style={{color:T.teal,fontWeight:700,fontFamily:T.mono,fontSize:11}}>{fmt(s.price)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
            <Input label="Quantity" value={form.qty} onChange={v=>setForm(f=>({...f,qty:v}))} type="number" placeholder="0"/>
            <Input label="Unit Price (Mwk)" value={form.price} onChange={v=>setForm(f=>({...f,price:v}))} type="number" placeholder="0.00"/>
            <Select label="Category" value={form.category} onChange={v=>setForm(f=>({...f,category:v}))} opts={CATEGORIES}/>
          </div>
          {form.qty&&form.price&&(
            <div style={{padding:"10px 14px",background:"#070f1c",borderRadius:9,display:"flex",justifyContent:"space-between",fontSize:13}}>
              <span style={{color:T.t2}}>Line Total</span>
              <span style={{color:T.teal,fontWeight:700,fontFamily:T.mono}}>{fmt(+form.qty * +form.price)}</span>
            </div>
          )}
          {flash==="success"&&<div style={{padding:"10px 14px",background:`${T.teal}15`,borderRadius:9,fontSize:12,color:T.teal,border:`1px solid ${T.teal}30`}}>✓ Purchase logged successfully!</div>}
          {flash==="error"&&<div style={{padding:"10px 14px",background:`${T.red}15`,borderRadius:9,fontSize:12,color:T.red,border:`1px solid ${T.red}30`}}>⚠ Please fill all required fields.</div>}
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
            <Btn v="outline" onClick={()=>setModalOpen(false)}>Cancel</Btn>
            <Btn onClick={addPurchase}>＋ Add Purchase</Btn>
          </div>
        </div>
      </Modal>

      {/* Delete confirm */}
      <Modal open={!!delId} onClose={()=>setDelId(null)} title="Confirm Delete" width={400}>
        <p style={{color:T.t2,fontSize:14,marginBottom:20}}>Are you sure you want to delete this purchase? This action cannot be undone.</p>
        <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
          <Btn v="outline" onClick={()=>setDelId(null)}>Cancel</Btn>
          <Btn v="danger" onClick={()=>deletePurchase(delId)}>Delete</Btn>
        </div>
      </Modal>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAGE: VENDORS
══════════════════════════════════════════════════════════════════════════ */
function Vendors({ vendors, setVendors, purchases, setPurchases, triggerAdd, clearTriggerAdd, addVendorDB, deleteVendorDB }) {
  const [selected,   setSelected]  = useState(null);
  const [showAdd,    setShowAdd]   = useState(false);
  const [delVId,     setDelVId]    = useState(null);
  const [delPId,     setDelPId]    = useState(null);
  const [searchDir,  setSearchDir] = useState("");
  const [filterCat,  setFilterCat] = useState("All");
  const [histSearch, setHistSearch]= useState("");
  const [form, setForm] = useState({ name:"", category:"Foods & Grocery", contact:"", phone:"", address:"" });
  const [formErr, setFormErr] = useState("");

  // Open the add modal if triggered from outside (e.g. Home quick action)
  useEffect(() => {
    if (triggerAdd) { setShowAdd(true); setFormErr(""); clearTriggerAdd && clearTriggerAdd(); }
  }, [triggerAdd]);

  /* ── vendor purchase stats ── */
  const stats = useMemo(()=>{
    const m={};
    purchases.forEach(p=>{
      if(!m[p.vendor]) m[p.vendor]={ spend:0, items:new Set(), orders:0, lastDate:"" };
      m[p.vendor].spend  += p.qty*p.price;
      m[p.vendor].items.add(p.item);
      m[p.vendor].orders += 1;
      if (p.date > m[p.vendor].lastDate) m[p.vendor].lastDate = p.date;
    });
    return m;
  },[purchases]);

  const grandTotal = Object.values(stats).reduce((s,v)=>s+v.spend, 0);

  /* ── category options for filter ── */
  const catOpts = useMemo(()=>
    ["All", ...new Set(vendors.map(v=>v.category))],
  [vendors]);

  /* ── filtered directory ── */
  const visibleVendors = useMemo(()=>{
    let list = vendors;
    if (searchDir.trim()) {
      const q = searchDir.toLowerCase();
      list = list.filter(v=>
        v.name.toLowerCase().includes(q) ||
        v.category.toLowerCase().includes(q)
      );
    }
    if (filterCat !== "All") list = list.filter(v=>v.category===filterCat);
    return list;
  },[vendors, searchDir, filterCat]);

  /* ── add vendor (local + optional DB) ── */
  const addVendor = async () => {
    if (!form.name.trim()) { setFormErr("Vendor name is required."); return; }
    if (vendors.find(v=>v.name.toLowerCase()===form.name.toLowerCase())) {
      setFormErr("A vendor with this name already exists."); return;
    }
    if (addVendorDB) {
      const err = await addVendorDB(form); // DB handles state update
      if (err) { setFormErr(err.message||"Error saving vendor."); return; }
    } else {
      setVendors(v=>[...v,{ id:uid(), ...form }]);
    }
    setForm({ name:"", category:"Foods & Grocery", contact:"", phone:"", address:"" });
    setFormErr("");
    setShowAdd(false);
  };

  const deleteVendor = async (id) => {
    if (deleteVendorDB) await deleteVendorDB(id); // handles state update
    else setVendors(v=>v.filter(x=>x.id!==id));
    if (selected?.id===id) setSelected(null);
    setDelVId(null);
  };

  /* ── DETAIL VIEW ── */
  if (selected) {
    const vs = stats[selected.name] || { spend:0, items:new Set(), orders:0, lastDate:"—" };
    const rawHistory = purchases.filter(p=>p.vendor===selected.name);
    const vendorPurchases = histSearch.trim()
      ? rawHistory.filter(p=>
          p.item.toLowerCase().includes(histSearch.toLowerCase()) ||
          p.category.toLowerCase().includes(histSearch.toLowerCase())
        )
      : rawHistory;
    const histTotal = rawHistory.reduce((s,p)=>s+p.qty*p.price, 0);
    const share = grandTotal>0 ? (vs.spend/grandTotal)*100 : 0;
    const initials = selected.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase();

    return (
      <div className="fade-up">
        {/* ── Breadcrumb header ── */}
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:24}}>
          <Btn v="ghost" s={{padding:"7px 12px",fontSize:12}} onClick={()=>{ setSelected(null); setHistSearch(""); }}>
            ← Vendors
          </Btn>
          <span style={{color:T.t3,fontSize:14}}>/</span>
          <span style={{fontSize:14,fontWeight:700,color:T.t1}}>{selected.name}</span>
          <div style={{marginLeft:"auto",display:"flex",gap:8}}>
            <Btn v="danger" s={{fontSize:12,padding:"7px 14px"}} onClick={()=>setDelVId(selected.id)}>🗑 Delete Vendor</Btn>
          </div>
        </div>

        {/* ── Hero profile strip ── */}
        <Card s={{marginBottom:16,padding:"20px 24px",background:`linear-gradient(135deg,#0d1e30,#0f2840)`}}>
          <div style={{display:"flex",alignItems:"center",gap:18}}>
            <div style={{width:58,height:58,borderRadius:16,background:`linear-gradient(135deg,${T.teal},${T.purple})`,
              display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,fontWeight:800,color:"#fff",flexShrink:0}}>
              {initials}
            </div>
            <div style={{flex:1}}>
              <div style={{fontSize:20,fontWeight:800,color:T.t1,letterSpacing:"-0.01em"}}>{selected.name}</div>
              <div style={{display:"flex",gap:10,marginTop:5,flexWrap:"wrap"}}>
                <Badge color={T.teal}>{selected.category}</Badge>
                {selected.address && <Badge color={T.t3}>📍 {selected.address}</Badge>}
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,auto)",gap:"0 28px",textAlign:"right"}}>
              {[
                {l:"Budget Share",v:`${share.toFixed(1)}%`,c:T.teal},
                {l:"Orders",v:vs.orders,c:T.purple},
                {l:"Last Order",v:vs.lastDate||"—",c:T.t2},
              ].map(x=>(
                <div key={x.l}>
                  <div style={{fontSize:10,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.09em",marginBottom:3}}>{x.l}</div>
                  <div style={{fontSize:15,fontWeight:800,color:x.c,fontFamily:T.mono}}>{x.v}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* ── KPI cards ── */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:16}}>
          {[
            {l:"Total Spend",   v:fmt(vs.spend),       c:T.teal},
            {l:"Unique Items",  v:vs.items?.size||0,    c:T.purple},
            {l:"Transactions",  v:vs.orders||0,         c:T.amber},
            {l:"Avg. Order",    v:fmt(vs.orders ? vs.spend/vs.orders : 0), c:T.green},
          ].map(x=>(
            <Card key={x.l} s={{borderTop:`2px solid ${x.c}`,padding:"14px 16px"}}>
              <div style={{fontSize:10,fontWeight:700,color:x.c,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:6}}>{x.l}</div>
              <div style={{fontSize:19,fontWeight:800,color:T.t1,fontFamily:T.mono}}>{x.v}</div>
            </Card>
          ))}
        </div>

        {/* ── Contact + History ── */}
        <div style={{display:"grid",gridTemplateColumns:"260px 1fr",gap:14}}>
          {/* Contact card */}
          <Card>
            <div style={{fontSize:13,fontWeight:700,color:T.t1,marginBottom:16}}>Contact Details</div>
            <div style={{display:"flex",flexDirection:"column",gap:14}}>
              {[
                {icon:"📧",label:"Email",    val:selected.contact, href: selected.contact ? `mailto:${selected.contact}` : null},
                {icon:"📞",label:"Phone",    val:selected.phone,   href: selected.phone   ? `tel:${selected.phone}`         : null},
                {icon:"📍",label:"Address",  val:selected.address, href: null},
                {icon:"🗂️",label:"Category", val:selected.category,href: null},
              ].map(({icon,label,val,href})=>(
                <div key={label} style={{paddingBottom:12,borderBottom:`1px solid ${T.border}`}}>
                  <div style={{fontSize:10,fontWeight:700,color:T.t3,textTransform:"uppercase",
                    letterSpacing:"0.09em",marginBottom:4}}>{icon} {label}</div>
                  {href ? (
                    <a href={href} style={{fontSize:13,color:T.teal,wordBreak:"break-all",
                      textDecoration:"none",display:"inline-flex",alignItems:"center",gap:5,
                      borderBottom:`1px dashed ${T.teal}55`,paddingBottom:1,transition:"color 0.15s"}}
                      onMouseEnter={e=>e.currentTarget.style.color=T.tealDim}
                      onMouseLeave={e=>e.currentTarget.style.color=T.teal}>
                      {val}
                      <span style={{fontSize:10,opacity:0.6}}>{label==="Email"?"↗":"↗"}</span>
                    </a>
                  ) : (
                    <div style={{fontSize:13,color:val?T.t2:T.t3,wordBreak:"break-all"}}>{val||"—"}</div>
                  )}
                </div>
              ))}
            </div>

            {/* Spend bar */}
            <div style={{marginTop:16}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
                <span style={{fontSize:11,color:T.t3}}>Budget share</span>
                <span style={{fontSize:11,fontWeight:700,color:T.teal,fontFamily:T.mono}}>{share.toFixed(1)}%</span>
              </div>
              <div style={{height:6,borderRadius:99,background:"#0a1628"}}>
                <div style={{height:"100%",width:`${share}%`,
                  background:`linear-gradient(90deg,${T.teal},${T.purple})`,borderRadius:99,transition:"width 0.8s ease"}}/>
              </div>
            </div>
          </Card>

          {/* Purchase history */}
          <Card s={{padding:0,overflow:"hidden"}}>
            <div style={{padding:"14px 18px",borderBottom:`1px solid ${T.border}`,
              display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"}}>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:T.t1}}>Purchase History</div>
                <div style={{fontSize:11,color:T.t2,marginTop:1}}>
                  {rawHistory.length} transaction{rawHistory.length!==1?"s":""} &nbsp;·&nbsp;
                  <span style={{color:T.teal,fontFamily:T.mono}}>{fmt(histTotal)}</span> total
                </div>
              </div>
              {/* History search */}
              <div style={{position:"relative",flex:"0 0 200px"}}>
                <span style={{position:"absolute",left:9,top:"50%",transform:"translateY(-50%)",
                  fontSize:12,color:T.t3,pointerEvents:"none"}}>🔍</span>
                <input value={histSearch} onChange={e=>setHistSearch(e.target.value)}
                  placeholder="Filter items…"
                  style={{background:"#070f1c",border:`1.5px solid ${histSearch?T.teal:T.border}`,
                    borderRadius:8,padding:"7px 10px 7px 28px",color:T.t1,fontSize:12,outline:"none",width:"100%",
                    transition:"border-color 0.2s"}}
                  onFocus={e=>e.target.style.borderColor=T.teal}
                  onBlur={e=>e.target.style.borderColor=histSearch?T.teal:T.border}/>
              </div>
            </div>

            <div style={{overflowY:"auto",maxHeight:400}}>
              <table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
                <thead style={{position:"sticky",top:0,zIndex:2}}>
                  <tr>
                    <Th>Date</Th><Th>Item</Th><Th>Category</Th>
                    <Th right>Qty</Th><Th right>Unit Price</Th><Th right>Total</Th>
                    <Th></Th>
                  </tr>
                </thead>
                <tbody>
                  {vendorPurchases.length===0 ? (
                    <tr><td colSpan={7} style={{padding:"36px",textAlign:"center",color:T.t3}}>
                      {histSearch ? "No items match your filter." : "No purchases from this vendor yet."}
                    </td></tr>
                  ) : vendorPurchases.map(p=>(
                    <tr key={p.id}
                      onMouseEnter={e=>e.currentTarget.style.background="#0f2236"}
                      onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                      <Td><span style={{fontFamily:T.mono,fontSize:11}}>{p.date}</span></Td>
                      <Td bold>{p.item}</Td>
                      <Td><Badge color={T.purple}>{p.category}</Badge></Td>
                      <Td right mono>{p.qty}</Td>
                      <Td right mono>{fmt(p.price)}</Td>
                      <Td right mono bold color={T.teal}>{fmt(p.qty*p.price)}</Td>
                      <td style={{padding:"8px 14px",borderBottom:`1px solid ${T.border}`}}>
                        <Btn v="ghost" s={{padding:"4px 8px",fontSize:11}} onClick={()=>setDelPId(p.id)}>🗑</Btn>
                      </td>
                    </tr>
                  ))}
                </tbody>
                {vendorPurchases.length>1 && (
                  <tfoot>
                    <tr style={{background:"#070f1c"}}>
                      <td colSpan={5} style={{padding:"10px 14px",textAlign:"right",fontWeight:700,color:T.t2,fontSize:12}}>
                        {histSearch ? `Filtered subtotal` : "Total"}
                      </td>
                      <td style={{padding:"10px 14px",textAlign:"right",fontWeight:800,color:T.teal,fontFamily:T.mono,fontSize:14}}>
                        {fmt(vendorPurchases.reduce((s,p)=>s+p.qty*p.price,0))}
                      </td>
                      <td style={{padding:"10px 14px"}}/>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </Card>
        </div>

        {/* Delete vendor modal */}
        <Modal open={!!delVId} onClose={()=>setDelVId(null)} title="Delete Vendor" width={420}>
          <div style={{padding:"14px 16px",background:`${T.red}12`,borderRadius:10,border:`1px solid ${T.red}25`,marginBottom:18}}>
            <div style={{fontSize:13,fontWeight:600,color:T.red,marginBottom:4}}>⚠ This action cannot be undone</div>
            <div style={{fontSize:12,color:T.t2}}>Deleting <strong style={{color:T.t1}}>{selected.name}</strong> removes them from your directory. Their purchase records will remain in your ledger.</div>
          </div>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
            <Btn v="outline" onClick={()=>setDelVId(null)}>Cancel</Btn>
            <Btn v="danger" onClick={()=>deleteVendor(delVId)}>Delete Vendor</Btn>
          </div>
        </Modal>

        {/* Delete purchase modal */}
        <Modal open={!!delPId} onClose={()=>setDelPId(null)} title="Delete Purchase Record" width={400}>
          <p style={{color:T.t2,fontSize:13,marginBottom:20}}>This will permanently remove this transaction from the ledger and update all reports and insights.</p>
          <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
            <Btn v="outline" onClick={()=>setDelPId(null)}>Cancel</Btn>
            <Btn v="danger" onClick={()=>{ setPurchases(p=>p.filter(x=>x.id!==delPId)); setDelPId(null); }}>Delete Record</Btn>
          </div>
        </Modal>
      </div>
    );
  }

  /* ── DIRECTORY VIEW ── */
  return (
    <div className="fade-up">
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:22}}>
        <div>
          <h1 style={{fontSize:22,fontWeight:800,color:T.t1,letterSpacing:"-0.02em"}}>Vendors</h1>
          <p style={{fontSize:13,color:T.t2,marginTop:3}}>
            Supplier directory — {vendors.length} registered partner{vendors.length!==1?"s":""}
          </p>
        </div>
        <Btn onClick={()=>{ setShowAdd(true); setFormErr(""); }}>＋ Add Vendor</Btn>
      </div>

      {/* Search + category filter */}
      <Card s={{padding:"14px 16px",marginBottom:16}}>
        <div style={{display:"flex",gap:12,flexWrap:"wrap",alignItems:"flex-end"}}>
          <div style={{flex:"1 1 200px",position:"relative"}}>
            <label style={{fontSize:10,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.1em",display:"block",marginBottom:5}}>Search Suppliers</label>
            <span style={{position:"absolute",left:11,bottom:11,fontSize:13,color:T.t3,pointerEvents:"none"}}>🔍</span>
            <input value={searchDir} onChange={e=>setSearchDir(e.target.value)}
              placeholder="Name or category…"
              style={{background:"#070f1c",border:`1.5px solid ${searchDir?T.teal:T.border}`,borderRadius:9,
                padding:"10px 12px 10px 32px",color:T.t1,fontSize:13,outline:"none",width:"100%",transition:"border-color 0.2s",
                boxShadow:searchDir?`0 0 0 3px ${T.tealGlow}`:"none"}}
              onFocus={e=>{e.target.style.borderColor=T.teal;e.target.style.boxShadow=`0 0 0 3px ${T.tealGlow}`;}}
              onBlur={e=>{e.target.style.borderColor=searchDir?T.teal:T.border;e.target.style.boxShadow=searchDir?`0 0 0 3px ${T.tealGlow}`:"none";}}/>
          </div>
          <div style={{flex:"0 0 180px"}}>
            <label style={{fontSize:10,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.1em",display:"block",marginBottom:5}}>Category</label>
            <select value={filterCat} onChange={e=>setFilterCat(e.target.value)}
              style={{background:"#070f1c",border:`1.5px solid ${filterCat!=="All"?T.teal:T.border}`,borderRadius:9,
                padding:"10px 12px",color:filterCat!=="All"?T.teal:T.t1,fontSize:13,outline:"none",width:"100%",cursor:"pointer",
                boxShadow:filterCat!=="All"?`0 0 0 3px ${T.tealGlow}`:"none"}}>
              {catOpts.map(o=><option key={o} value={o} style={{background:"#070f1c",color:T.t1}}>{o}</option>)}
            </select>
          </div>
          {(searchDir||filterCat!=="All") && (
            <Btn v="ghost" s={{marginTop:"auto"}} onClick={()=>{setSearchDir("");setFilterCat("All");}}>✕ Clear</Btn>
          )}
          <div style={{marginLeft:"auto",marginTop:"auto"}}>
            <Badge color={T.teal} s={{fontSize:12,padding:"6px 12px"}}>{visibleVendors.length} result{visibleVendors.length!==1?"s":""}</Badge>
          </div>
        </div>
      </Card>

      {/* Vendor grid */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(300px,1fr))",gap:14}}>
        {visibleVendors.map(v=>{
          const vs = stats[v.name]||{spend:0,items:new Set(),orders:0};
          const share = grandTotal>0?(vs.spend/grandTotal)*100:0;
          return (
            <div key={v.id} onClick={()=>setSelected(v)}
              style={{background:T.cardBg,border:`1px solid ${T.border}`,borderRadius:16,padding:20,
                cursor:"pointer",transition:"all 0.18s"}}
              onMouseEnter={e=>{e.currentTarget.style.background=T.cardBg2;e.currentTarget.style.borderColor=T.border2;e.currentTarget.style.transform="translateY(-2px)";}}
              onMouseLeave={e=>{e.currentTarget.style.background=T.cardBg;e.currentTarget.style.borderColor=T.border;e.currentTarget.style.transform="none";}}>

              {/* Header */}
              <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:14}}>
                <div style={{width:44,height:44,borderRadius:12,background:`linear-gradient(135deg,${T.teal},${T.purple})`,
                  display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,fontWeight:800,color:"#fff",flexShrink:0}}>
                  {v.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase()}
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:14,fontWeight:700,color:T.t1,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{v.name}</div>
                  <Badge color={T.teal} s={{fontSize:10,marginTop:3,display:"inline-block"}}>{v.category}</Badge>
                </div>
                <span style={{fontSize:11,color:T.t3}}>→</span>
              </div>

              {/* Stats row */}
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:12}}>
                {[
                  {l:"Spend",    v:fmtK(vs.spend)},
                  {l:"Orders",   v:vs.orders||0},
                  {l:"Items",    v:vs.items?.size||0},
                ].map(x=>(
                  <div key={x.l} style={{background:"#070f1c",borderRadius:8,padding:"8px 10px"}}>
                    <div style={{fontSize:9,color:T.t3,fontWeight:700,textTransform:"uppercase",letterSpacing:"0.08em",marginBottom:3}}>{x.l}</div>
                    <div style={{fontSize:13,fontWeight:800,color:T.t1,fontFamily:T.mono}}>{x.v}</div>
                  </div>
                ))}
              </div>

              {/* Budget share bar */}
              <div>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                  <span style={{fontSize:10,color:T.t3}}>Budget share</span>
                  <span style={{fontSize:10,fontWeight:700,color:T.teal,fontFamily:T.mono}}>{share.toFixed(1)}%</span>
                </div>
                <div style={{height:4,borderRadius:99,background:"#0a1628"}}>
                  <div style={{height:"100%",width:`${share}%`,background:`linear-gradient(90deg,${T.teal},${T.purple})`,borderRadius:99,transition:"width 0.7s ease"}}/>
                </div>
              </div>

              {/* Contact footer */}
              {(v.contact||v.phone) && (
                <div style={{marginTop:10,paddingTop:10,borderTop:`1px solid ${T.border}`,
                  display:"flex",gap:14,fontSize:11,flexWrap:"wrap"}}
                  onClick={e=>e.stopPropagation()}>
                  {v.contact && (
                    <a href={`mailto:${v.contact}`}
                      style={{color:T.teal,textDecoration:"none",display:"flex",alignItems:"center",gap:4,transition:"color 0.15s"}}
                      onMouseEnter={e=>e.currentTarget.style.color=T.tealDim}
                      onMouseLeave={e=>e.currentTarget.style.color=T.teal}>
                      📧 {v.contact}
                    </a>
                  )}
                  {v.phone && (
                    <a href={`tel:${v.phone}`}
                      style={{color:T.purple,textDecoration:"none",display:"flex",alignItems:"center",gap:4,transition:"color 0.15s"}}
                      onMouseEnter={e=>e.currentTarget.style.color="#6b4e97"}
                      onMouseLeave={e=>e.currentTarget.style.color=T.purple}>
                      📞 {v.phone}
                    </a>
                  )}
                </div>
              )}
            </div>
          );
        })}

        {visibleVendors.length===0 && (
          <div style={{gridColumn:"1/-1",textAlign:"center",padding:"60px 20px"}}>
            <div style={{fontSize:32,marginBottom:12}}>🏭</div>
            <div style={{fontSize:14,fontWeight:600,color:T.t2,marginBottom:6}}>
              {vendors.length===0 ? "No vendors registered yet" : "No vendors match your search"}
            </div>
            <div style={{fontSize:12,color:T.t3}}>
              {vendors.length===0 ? "Click \"Add Vendor\" to register your first supplier." : "Try clearing your search filters."}
            </div>
          </div>
        )}
      </div>

      {/* Add Vendor modal */}
      <Modal open={showAdd} onClose={()=>{ setShowAdd(false); setFormErr(""); }} title="Add New Vendor" width={520}>
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          {/* Preview strip */}
          {form.name && (
            <div style={{display:"flex",alignItems:"center",gap:12,padding:"12px 14px",background:"#070f1c",borderRadius:10,border:`1px solid ${T.border}`}}>
              <div style={{width:36,height:36,borderRadius:10,background:`linear-gradient(135deg,${T.teal},${T.purple})`,
                display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,fontWeight:800,color:"#fff",flexShrink:0}}>
                {form.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase()}
              </div>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:T.t1}}>{form.name}</div>
                <div style={{fontSize:11,color:T.t2}}>{form.category}</div>
              </div>
            </div>
          )}

          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Input label="Vendor Name *" value={form.name}
              onChange={v=>{ setForm(f=>({...f,name:capFirst(v)})); setFormErr(""); }}
              placeholder="e.g. Fresh Mart"/>
            <Select label="Category *" value={form.category}
              onChange={v=>setForm(f=>({...f,category:v}))}
              opts={["Foods & Grocery","Beverages","Cleaning Supplies","Stationery","Electronics","Other"]}/>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <Input label="Email" value={form.contact}
              onChange={v=>setForm(f=>({...f,contact:v}))}
              placeholder="vendor@example.com"/>
            <Input label="Phone" value={form.phone}
              onChange={v=>setForm(f=>({...f,phone:v}))}
              placeholder="+265 999 000"/>
          </div>
          <Input label="Address" value={form.address}
            onChange={v=>setForm(f=>({...f,address:capFirst(v)}))}
            placeholder="e.g. Market Square, Lilongwe"/>

          {formErr && (
            <div style={{padding:"9px 13px",background:`${T.red}15`,borderRadius:9,fontSize:12,color:T.red,border:`1px solid ${T.red}30`}}>
              ⚠ {formErr}
            </div>
          )}

          <div style={{display:"flex",gap:10,justifyContent:"flex-end",paddingTop:4}}>
            <Btn v="outline" onClick={()=>{ setShowAdd(false); setFormErr(""); }}>Cancel</Btn>
            <Btn onClick={addVendor}>Add Vendor</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAGE: INSIGHTS
══════════════════════════════════════════════════════════════════════════ */
function Insights({ purchases }) {
  const total = purchases.reduce((s,p)=>s+p.qty*p.price,0);

  const supplierData = useMemo(()=>{
    const m={};
    purchases.forEach(p=>{
      if(!m[p.vendor]) m[p.vendor]={ vendor:p.vendor, items:new Set(), qty:0, spend:0 };
      m[p.vendor].items.add(p.item);
      m[p.vendor].qty+=p.qty;
      m[p.vendor].spend+=p.qty*p.price;
    });
    return Object.values(m).map(v=>({...v,items:v.items.size,pct:total>0?(v.spend/total)*100:0})).sort((a,b)=>b.spend-a.spend);
  },[purchases,total]);

  const catData = useMemo(()=>{
    const m={};
    purchases.forEach(p=>{ m[p.category]=(m[p.category]||0)+p.qty*p.price; });
    return Object.entries(m).sort((a,b)=>b[1]-a[1]).map(([label,value])=>({label,value,pct:total>0?(value/total)*100:0}));
  },[purchases,total]);

  return (
    <div className="fade-up">
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:22,fontWeight:800,color:T.t1,letterSpacing:"-0.02em"}}>Insights</h1>
        <p style={{fontSize:13,color:T.t2,marginTop:3}}>Data-driven analytics — manually computed from your records</p>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:14,marginBottom:20}}>
        {[
          {l:"Total Spend",v:fmt(total),c:T.teal},
          {l:"Suppliers",v:supplierData.length,c:T.purple},
          {l:"Categories",v:catData.length,c:T.amber},
        ].map(x=>(
          <Card key={x.l} s={{padding:"16px 20px"}}>
            <div style={{fontSize:10,fontWeight:700,color:x.c,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:8}}>{x.l}</div>
            <div style={{fontSize:24,fontWeight:800,color:T.t1,fontFamily:T.mono}}>{x.v}</div>
          </Card>
        ))}
      </div>

      {/* Supplier Table */}
      <Card s={{marginBottom:16,padding:0,overflow:"hidden"}}>
        <div style={{padding:"16px 20px",borderBottom:`1px solid ${T.border}`}}>
          <div style={{fontSize:14,fontWeight:700,color:T.t1}}>Supplier Spending Analysis</div>
          <div style={{fontSize:11,color:T.t2,marginTop:2}}>Unique items, quantities, and budget share per vendor</div>
        </div>
        <div style={{overflowX:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse"}}>
            <thead><tr><Th>Vendor</Th><Th right>Unique Items</Th><Th right>Total Qty</Th><Th right>Total Spend</Th><Th right>Budget %</Th><Th>Share Bar</Th></tr></thead>
            <tbody>{supplierData.length===0
              ? <tr><td colSpan={6} style={{padding:"40px",textAlign:"center",color:T.t3}}>No data yet.</td></tr>
              : supplierData.map((r,i)=>(
                <tr key={r.vendor} onMouseEnter={e=>e.currentTarget.style.background="#0f2236"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                  <td style={{padding:"11px 14px",borderBottom:`1px solid ${T.border}`}}>
                    <div style={{display:"flex",alignItems:"center",gap:10}}>
                      <div style={{width:28,height:28,borderRadius:8,background:`linear-gradient(135deg,${COLORS[i%COLORS.length]},${COLORS[(i+1)%COLORS.length]})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:800,color:"#fff",flexShrink:0}}>{r.vendor[0]}</div>
                      <span style={{fontWeight:600,color:T.t1}}>{r.vendor}</span>
                    </div>
                  </td>
                  <Td right mono bold>{r.items}</Td>
                  <Td right mono>{r.qty}</Td>
                  <Td right mono bold color={T.teal}>{fmt(r.spend)}</Td>
                  <Td right mono bold color={T.amber}>{r.pct.toFixed(1)}%</Td>
                  <td style={{padding:"11px 14px",borderBottom:`1px solid ${T.border}`,minWidth:120}}>
                    <div style={{height:6,borderRadius:99,background:"#0a1628"}}>
                      <div style={{height:"100%",width:`${r.pct}%`,background:COLORS[i%COLORS.length],borderRadius:99}}/>
                    </div>
                  </td>
                </tr>
              ))
            }</tbody>
          </table>
        </div>
      </Card>

      {/* Category Progress */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
        <Card>
          <div style={{fontSize:14,fontWeight:700,color:T.t1,marginBottom:18}}>Category Metrics</div>
          {catData.map((c,i)=>(
            <ProgBar key={c.label} label={`${CAT_ICON[c.label]||"📦"} ${c.label}`} value={c.value} max={catData[0]?.value||1} color={COLORS[i%COLORS.length]} sub={`${c.pct.toFixed(1)}%`}/>
          ))}
          {catData.length===0&&<div style={{textAlign:"center",padding:"30px 0",color:T.t3}}>No data.</div>}
        </Card>
        <Card>
          <div style={{fontSize:14,fontWeight:700,color:T.t1,marginBottom:18}}>Distribution</div>
          <Donut data={catData} total={total} size={160}/>
          <div style={{marginTop:20,paddingTop:16,borderTop:`1px solid ${T.border}`}}>
            {catData.map((c,i)=>(
              <div key={c.label} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 0",borderBottom:i<catData.length-1?`1px solid ${T.border}`:"none"}}>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <span style={{width:8,height:8,borderRadius:"50%",background:COLORS[i%COLORS.length]}}/>
                  <span style={{fontSize:12,color:T.t2}}>{CAT_ICON[c.label]||"📦"} {c.label}</span>
                </div>
                <span style={{fontSize:12,fontWeight:700,color:T.t1,fontFamily:T.mono}}>{fmtK(c.value)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAGE: REPORTS
══════════════════════════════════════════════════════════════════════════ */
function Reports({ purchases, vendors }) {
  const allVendors = useMemo(()=>["All",...new Set(purchases.map(p=>p.vendor))],[purchases]);
  const [filter, setFilter] = useState({ vendor:"All", category:"All", from:"", to:"" });

  const data = useMemo(()=>purchases.filter(p=>{
    if(filter.vendor!=="All"&&p.vendor!==filter.vendor) return false;
    if(filter.category!=="All"&&p.category!==filter.category) return false;
    if(filter.from&&p.date<filter.from) return false;
    if(filter.to&&p.date>filter.to) return false;
    return true;
  }),[purchases,filter]);

  const total = data.reduce((s,p)=>s+p.qty*p.price,0);
  const totalQty = data.reduce((s,p)=>s+p.qty,0);
  const uniqueVendors = new Set(data.map(p=>p.vendor)).size;

  const exportPDF = () => {
    const win = window.open("","_blank");
    const catTotals={};
    data.forEach(p=>{ catTotals[p.category]=(catTotals[p.category]||0)+p.qty*p.price; });
    const catRows = Object.entries(catTotals).sort((a,b)=>b[1]-a[1]).map(([c,v])=>`<tr><td>${CAT_ICON[c]||""} ${c}</td><td style="text-align:right">${fmt(v)}</td><td style="text-align:right">${total>0?((v/total)*100).toFixed(1):0}%</td></tr>`).join("");
    const pRows = data.map(p=>`<tr><td>${p.date}</td><td>${p.vendor}</td><td>${p.item}</td><td>${p.category}</td><td style="text-align:center">${p.qty}</td><td style="text-align:right">${fmt(p.price)}</td><td style="text-align:right;font-weight:700">${fmt(p.qty*p.price)}</td></tr>`).join("");
    win.document.write(`<!DOCTYPE html><html><head><title>Procurement Report</title>
    <style>@import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&display=swap');
    *{box-sizing:border-box;margin:0;padding:0;}
    body{font-family:'Sora',sans-serif;background:#0a1628;color:#c8ddf0;padding:48px;}
    .header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:32px;padding-bottom:20px;border-bottom:1px solid #162840;}
    h1{color:#0fb8a4;font-size:28px;font-weight:800;letter-spacing:-0.02em;}
    .meta{color:#3a5a78;font-size:12px;margin-top:6px;}
    .stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:28px;}
    .stat{background:#0d1e30;border:1px solid #162840;border-radius:12px;padding:16px 18px;}
    .stat-label{font-size:10px;font-weight:700;color:#3a5a78;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:8px;}
    .stat-value{font-size:20px;font-weight:800;color:#e2eff8;}
    .section{margin-bottom:28px;}
    .section-title{font-size:13px;font-weight:700;color:#e2eff8;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #162840;}
    table{width:100%;border-collapse:collapse;font-size:12px;}
    th{padding:9px 12px;text-align:left;background:#070f1c;color:#3a5a78;font-weight:700;font-size:10px;text-transform:uppercase;letter-spacing:0.08em;border-bottom:1px solid #162840;}
    td{padding:9px 12px;border-bottom:1px solid #162840;color:#7a9dba;}
    tr:hover td{background:#0d1e30;}
    .grand{text-align:right;font-size:14px;font-weight:700;color:#7b5ea7;margin-top:14px;}
    .badge{background:#0fb8a41a;color:#0fb8a4;border-radius:99px;padding:2px 8px;font-size:10px;font-weight:600;}
    </style></head><body>
    <div class="header"><div><h1>Procurement Report</h1><div class="meta">Generated: ${new Date().toLocaleDateString("en-US",{dateStyle:"long"})} &nbsp;|&nbsp; Vendor: ${filter.vendor} &nbsp;|&nbsp; Category: ${filter.category}</div></div><div style="text-align:right;color:#3a5a78;font-size:11px;">ProcureDesk v2.0<br/>Confidential</div></div>
    <div class="stats"><div class="stat"><div class="stat-label">Total Spend</div><div class="stat-value">${fmt(total)}</div></div><div class="stat"><div class="stat-label">Transactions</div><div class="stat-value">${data.length}</div></div><div class="stat"><div class="stat-label">Total Units</div><div class="stat-value">${totalQty}</div></div><div class="stat"><div class="stat-label">Vendors</div><div class="stat-value">${uniqueVendors}</div></div></div>
    <div class="section"><div class="section-title">Spend by Category</div><table><thead><tr><th>Category</th><th style="text-align:right">Amount</th><th style="text-align:right">% of Total</th></tr></thead><tbody>${catRows}</tbody></table></div>
    <div class="section"><div class="section-title">Transaction Ledger</div><table><thead><tr><th>Date</th><th>Vendor</th><th>Item</th><th>Category</th><th style="text-align:center">Qty</th><th style="text-align:right">Unit Price</th><th style="text-align:right">Total</th></tr></thead><tbody>${pRows}</tbody></table><div class="grand">Grand Total: ${fmt(total)}</div></div>
    </body></html>`);
    win.document.close(); setTimeout(()=>win.print(),400);
  };

  return (
    <div className="fade-up">
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:22,fontWeight:800,color:T.t1,letterSpacing:"-0.02em"}}>Reports</h1>
        <p style={{fontSize:13,color:T.t2,marginTop:3}}>Executive procurement summary — filter and export</p>
      </div>

      {/* Filters */}
      <Card s={{marginBottom:18}}>
        <div style={{display:"flex",gap:14,flexWrap:"wrap",alignItems:"flex-end"}}>
          <Select label="Vendor" value={filter.vendor} onChange={v=>setFilter(f=>({...f,vendor:v}))} opts={allVendors}/>
          <Select label="Category" value={filter.category} onChange={v=>setFilter(f=>({...f,category:v}))} opts={["All",...CATEGORIES]}/>
          <Input label="From Date" value={filter.from} onChange={v=>setFilter(f=>({...f,from:v}))} type="date"/>
          <Input label="To Date" value={filter.to} onChange={v=>setFilter(f=>({...f,to:v}))} type="date"/>
          <Btn v="amber" onClick={()=>setFilter({vendor:"All",category:"All",from:"",to:""})} s={{marginBottom:0}}>Clear</Btn>
          <Btn v="purple" onClick={exportPDF} s={{marginLeft:"auto"}}>⬇ Download PDF</Btn>
        </div>
      </Card>

      {/* Summary */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:18}}>
        {[
          {l:"Transactions",v:data.length,c:T.teal},
          {l:"Total Spend",v:fmt(total),c:T.purple},
          {l:"Total Units",v:totalQty,c:T.amber},
          {l:"Vendors",v:uniqueVendors,c:T.green},
        ].map(x=>(
          <Card key={x.l} s={{padding:"16px 18px"}}>
            <div style={{fontSize:10,fontWeight:700,color:x.c,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:8}}>{x.l}</div>
            <div style={{fontSize:22,fontWeight:800,color:T.t1,fontFamily:T.mono}}>{x.v}</div>
          </Card>
        ))}
      </div>

      <Card s={{padding:0,overflow:"hidden"}}>
        <div style={{padding:"16px 20px",borderBottom:`1px solid ${T.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div style={{fontSize:14,fontWeight:700,color:T.t1}}>Transaction Ledger</div>
          <Badge>{data.length} records</Badge>
        </div>
        <div style={{overflowX:"auto",maxHeight:500,overflowY:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
            <thead style={{position:"sticky",top:0,zIndex:2}}><tr><Th>Date</Th><Th>Vendor</Th><Th>Item</Th><Th>Category</Th><Th right>Qty</Th><Th right>Unit Price</Th><Th right>Total</Th></tr></thead>
            <tbody>
              {data.length===0
                ? <tr><td colSpan={7} style={{padding:"40px",textAlign:"center",color:T.t3}}>No records match your filters.</td></tr>
                : data.map(p=>(
                  <tr key={p.id} onMouseEnter={e=>e.currentTarget.style.background="#0f2236"} onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                    <Td><span style={{fontFamily:T.mono,fontSize:11}}>{p.date}</span></Td>
                    <Td bold>{p.vendor}</Td>
                    <Td>{p.item}</Td>
                    <Td><Badge color={T.purple}>{p.category}</Badge></Td>
                    <Td right mono>{p.qty}</Td>
                    <Td right mono>{fmt(p.price)}</Td>
                    <Td right mono bold color={T.teal}>{fmt(p.qty*p.price)}</Td>
                  </tr>
                ))
              }
              {data.length>0&&(
                <tr style={{background:"#070f1c"}}>
                  <td colSpan={6} style={{padding:"12px 14px",textAlign:"right",fontWeight:700,color:T.t2,fontSize:12}}>Grand Total</td>
                  <td style={{padding:"12px 14px",textAlign:"right",fontWeight:800,color:T.purple,fontFamily:T.mono,fontSize:15}}>{fmt(total)}</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAGE: CATALOG
══════════════════════════════════════════════════════════════════════════ */
function Catalog({ purchases }) {
  const [search, setSearch]       = useState("");
  const [filterVendor, setFV]     = useState("All");
  const [filterCategory, setFC]   = useState("All");
  const [sortBy, setSortBy]       = useState("item"); // item | price | spend | date
  const [sortDir, setSortDir]     = useState("asc");
  const [expanded, setExpanded]   = useState(null); // item key for price-history expand

  /* ── Build deduplicated catalog ── */
  const catalog = useMemo(() => {
    const m = {};
    purchases.forEach(p => {
      const key = p.item.toLowerCase().trim();
      if (!m[key]) {
        m[key] = {
          key,
          item: p.item,
          category: p.category,
          lastPrice: p.price,
          lastVendor: p.vendor,
          lastDate: p.date,
          firstDate: p.date,
          totalQty: 0,
          totalSpend: 0,
          orderCount: 0,
          allVendors: new Set(),
          priceHistory: [],   // { date, vendor, price, qty }
        };
      }
      const e = m[key];
      // track most-recent price
      if (p.date > e.lastDate || (p.date === e.lastDate && p.price !== e.lastPrice)) {
        if (p.date >= e.lastDate) { e.lastPrice = p.price; e.lastVendor = p.vendor; e.lastDate = p.date; }
      }
      if (p.date < e.firstDate) e.firstDate = p.date;
      e.totalQty    += p.qty;
      e.totalSpend  += p.qty * p.price;
      e.orderCount  += 1;
      e.allVendors.add(p.vendor);
      e.priceHistory.push({ date: p.date, vendor: p.vendor, price: p.price, qty: p.qty });
    });

    return Object.values(m).map(x => ({
      ...x,
      vendorCount: x.allVendors.size,
      vendors: Array.from(x.allVendors),
      priceHistory: x.priceHistory.sort((a, b) => b.date.localeCompare(a.date)),
      // price trend: compare latest vs second-latest price from history
      priceTrend: (() => {
        const h = x.priceHistory.slice().sort((a,b)=>b.date.localeCompare(a.date));
        if (h.length < 2) return "stable";
        return h[0].price > h[1].price ? "up" : h[0].price < h[1].price ? "down" : "stable";
      })(),
    }));
  }, [purchases]);

  /* ── Unique filter options ── */
  const vendorOpts   = useMemo(() => ["All", ...new Set(catalog.flatMap(c => c.vendors))], [catalog]);
  const categoryOpts = useMemo(() => ["All", ...new Set(catalog.map(c => c.category))],   [catalog]);

  /* ── Filter + sort ── */
  const filtered = useMemo(() => {
    let rows = catalog;
    if (search.trim()) {
      const q = search.toLowerCase();
      rows = rows.filter(c =>
        c.item.toLowerCase().includes(q) ||
        c.category.toLowerCase().includes(q) ||
        c.vendors.some(v => v.toLowerCase().includes(q))
      );
    }
    if (filterVendor   !== "All") rows = rows.filter(c => c.vendors.includes(filterVendor));
    if (filterCategory !== "All") rows = rows.filter(c => c.category === filterCategory);

    rows = [...rows].sort((a, b) => {
      let va, vb;
      if (sortBy === "item")  { va = a.item;        vb = b.item; }
      if (sortBy === "price") { va = a.lastPrice;   vb = b.lastPrice; }
      if (sortBy === "spend") { va = a.totalSpend;  vb = b.totalSpend; }
      if (sortBy === "date")  { va = a.lastDate;    vb = b.lastDate; }
      if (typeof va === "string") return sortDir === "asc" ? va.localeCompare(vb) : vb.localeCompare(va);
      return sortDir === "asc" ? va - vb : vb - va;
    });
    return rows;
  }, [catalog, search, filterVendor, filterCategory, sortBy, sortDir]);

  const toggleSort = col => {
    if (sortBy === col) setSortDir(d => d === "asc" ? "desc" : "asc");
    else { setSortBy(col); setSortDir("asc"); }
  };

  const SortTh = ({ col, children, right }) => {
    const active = sortBy === col;
    return (
      <th onClick={() => toggleSort(col)} style={{
        padding: "10px 14px", textAlign: right ? "right" : "left",
        background: "#070f1c", color: active ? T.teal : T.t3,
        fontWeight: 700, fontSize: 10, textTransform: "uppercase", letterSpacing: "0.1em",
        borderBottom: `1px solid ${T.border}`, whiteSpace: "nowrap",
        cursor: "pointer", userSelect: "none",
        transition: "color 0.15s",
      }}>
        {children} {active ? (sortDir === "asc" ? "↑" : "↓") : <span style={{opacity:0.3}}>↕</span>}
      </th>
    );
  };

  const TrendIcon = ({ trend }) => {
    if (trend === "up")   return <span style={{color:"#e05c5c",fontSize:13,fontWeight:700}}>↑</span>;
    if (trend === "down") return <span style={{color:T.green,fontSize:13,fontWeight:700}}>↓</span>;
    return <span style={{color:T.t3,fontSize:12}}>—</span>;
  };

  /* ── Category colour map ── */
  const CAT_COLOR = {
    Foods: T.teal, Beverages: "#6366f1", Cleaning: T.purple,
    Stationery: T.amber, Electronics: T.green, Other: T.t2,
  };

  /* ── Summary stats ── */
  const totalItems   = catalog.length;
  const totalFiltered = filtered.length;
  const avgPrice     = filtered.length ? filtered.reduce((s,c)=>s+c.lastPrice,0)/filtered.length : 0;
  const topSpend     = filtered.reduce((top,c)=>c.totalSpend>top.totalSpend?c:top, filtered[0]||{});

  const hasFilters = search.trim() || filterVendor !== "All" || filterCategory !== "All";

  return (
    <div className="fade-up">
      {/* Header */}
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:22,fontWeight:800,color:T.t1,letterSpacing:"-0.02em"}}>Catalog</h1>
        <p style={{fontSize:13,color:T.t2,marginTop:3}}>
          Auto-deduplicated reference library — {totalItems} unique item{totalItems!==1?"s":""} across your entire purchase history
        </p>
      </div>

      {/* Summary strip */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:18}}>
        {[
          { l:"Unique Items",    v:totalItems,             c:T.teal,   icon:"📦" },
          { l:"Showing",        v:`${totalFiltered} items`, c:T.purple, icon:"🔎" },
          { l:"Avg. Last Price", v:fmt(avgPrice),          c:T.amber,  icon:"💲" },
          { l:"Top Spend Item",  v:topSpend?.item||"—",    c:T.green,  icon:"⭐", small:true },
        ].map(x=>(
          <Card key={x.l} s={{padding:"14px 16px",borderTop:`2px solid ${x.c}`}}>
            <div style={{fontSize:10,fontWeight:700,color:x.c,textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:6}}>{x.l}</div>
            <div style={{fontSize:x.small?13:20,fontWeight:800,color:T.t1,fontFamily:x.small?"inherit":T.mono,
              whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>{x.v}</div>
          </Card>
        ))}
      </div>

      {/* Search + Filters bar */}
      <Card s={{padding:"14px 16px",marginBottom:16}}>
        <div style={{display:"flex",gap:12,flexWrap:"wrap",alignItems:"flex-end"}}>
          {/* Search */}
          <div style={{flex:"2 1 200px",position:"relative"}}>
            <label style={{fontSize:10,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.1em",display:"block",marginBottom:5}}>Search Items</label>
            <span style={{position:"absolute",left:12,bottom:11,fontSize:13,color:T.t3,pointerEvents:"none"}}>🔍</span>
            <input value={search} onChange={e=>setSearch(e.target.value)}
              placeholder="Item name, category, or vendor…"
              style={{ background:"#070f1c", border:`1.5px solid ${search?T.teal:T.border}`, borderRadius:9,
                padding:"10px 13px 10px 34px", color:T.t1, fontSize:13, outline:"none", width:"100%",
                transition:"border-color 0.2s", boxShadow: search?`0 0 0 3px ${T.tealGlow}`:"none" }}
              onFocus={e=>{e.target.style.borderColor=T.teal;e.target.style.boxShadow=`0 0 0 3px ${T.tealGlow}`;}}
              onBlur={e=>{e.target.style.borderColor=search?T.teal:T.border;e.target.style.boxShadow=search?`0 0 0 3px ${T.tealGlow}`:"none";}}/>
          </div>

          {/* Vendor filter */}
          <div style={{flex:"1 1 140px"}}>
            <label style={{fontSize:10,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.1em",display:"block",marginBottom:5}}>Vendor</label>
            <select value={filterVendor} onChange={e=>setFV(e.target.value)}
              style={{ background:"#070f1c", border:`1.5px solid ${filterVendor!=="All"?T.teal:T.border}`,
                borderRadius:9, padding:"10px 12px", color:T.t1, fontSize:13, outline:"none", width:"100%",
                cursor:"pointer", boxShadow:filterVendor!=="All"?`0 0 0 3px ${T.tealGlow}`:"none" }}>
              {vendorOpts.map(o=><option key={o} value={o} style={{background:"#070f1c"}}>{o}</option>)}
            </select>
          </div>

          {/* Category filter */}
          <div style={{flex:"1 1 140px"}}>
            <label style={{fontSize:10,fontWeight:700,color:T.t3,textTransform:"uppercase",letterSpacing:"0.1em",display:"block",marginBottom:5}}>Category</label>
            <select value={filterCategory} onChange={e=>setFC(e.target.value)}
              style={{ background:"#070f1c", border:`1.5px solid ${filterCategory!=="All"?T.purple:T.border}`,
                borderRadius:9, padding:"10px 12px", color:T.t1, fontSize:13, outline:"none", width:"100%",
                cursor:"pointer", boxShadow:filterCategory!=="All"?`0 0 0 3px ${T.purpleGlow}`:"none" }}>
              {categoryOpts.map(o=><option key={o} value={o} style={{background:"#070f1c"}}>{CAT_ICON[o]||""} {o}</option>)}
            </select>
          </div>

          {/* Clear */}
          {hasFilters && (
            <Btn v="ghost" s={{marginTop:"auto",whiteSpace:"nowrap"}}
              onClick={()=>{setSearch("");setFV("All");setFC("All");}}>
              ✕ Clear
            </Btn>
          )}
        </div>

        {/* Active filter chips */}
        {hasFilters && (
          <div style={{display:"flex",gap:8,marginTop:12,flexWrap:"wrap",alignItems:"center"}}>
            <span style={{fontSize:11,color:T.t3}}>Active filters:</span>
            {search.trim() && <Badge color={T.teal} s={{cursor:"pointer"}} onClick={()=>setSearch("")}>"{search}" ✕</Badge>}
            {filterVendor!=="All" && <Badge color={T.teal} s={{cursor:"pointer"}} onClick={()=>setFV("All")}>{filterVendor} ✕</Badge>}
            {filterCategory!=="All" && <Badge color={T.purple} s={{cursor:"pointer"}} onClick={()=>setFC("All")}>{CAT_ICON[filterCategory]||""} {filterCategory} ✕</Badge>}
            <span style={{fontSize:11,color:T.t2,marginLeft:4}}>{filtered.length} result{filtered.length!==1?"s":""}</span>
          </div>
        )}
      </Card>

      {/* Category quick-filter pills */}
      <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:16}}>
        {["All",...CATEGORIES].map(cat=>{
          const isActive = filterCategory===cat||(cat==="All"&&filterCategory==="All");
          const color = CAT_COLOR[cat]||T.teal;
          const count = cat==="All" ? catalog.length : catalog.filter(c=>c.category===cat).length;
          if (cat!=="All" && count===0) return null;
          return (
            <button key={cat} onClick={()=>setFC(cat==="All"?"All":cat)}
              style={{ border:`1.5px solid ${isActive?(CAT_COLOR[cat]||T.teal):T.border}`,
                borderRadius:99, padding:"5px 14px", fontSize:12, fontWeight:600,
                background: isActive?`${CAT_COLOR[cat]||T.teal}18`:"transparent",
                color: isActive?(CAT_COLOR[cat]||T.teal):T.t3,
                cursor:"pointer", transition:"all 0.15s", display:"flex", alignItems:"center", gap:5 }}>
              {cat!=="All"&&<span>{CAT_ICON[cat]||"📦"}</span>}
              {cat}
              <span style={{background:isActive?`${CAT_COLOR[cat]||T.teal}30`:"#0d1e30",borderRadius:99,padding:"1px 7px",fontSize:10,fontFamily:T.mono}}>{count}</span>
            </button>
          );
        })}
      </div>

      {/* Main table */}
      <Card s={{padding:0,overflow:"hidden"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 18px",borderBottom:`1px solid ${T.border}`}}>
          <div style={{fontSize:13,fontWeight:700,color:T.t1}}>Item Directory</div>
          <div style={{fontSize:11,color:T.t3}}>Click column headers to sort · Click row to view price history</div>
        </div>

        <div style={{overflowX:"auto",maxHeight:580,overflowY:"auto"}}>
          <table style={{width:"100%",borderCollapse:"collapse",fontSize:13}}>
            <thead style={{position:"sticky",top:0,zIndex:2}}>
              <tr>
                <SortTh col="item">Item</SortTh>
                <Th>Category</Th>
                <Th>Vendors</Th>
                <SortTh col="price" right>Last Price</SortTh>
                <Th right>Trend</Th>
                <Th right>Orders</Th>
                <SortTh col="spend" right>Total Spend</SortTh>
                <SortTh col="date" right>Last Purchased</SortTh>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} style={{padding:"60px 20px",textAlign:"center"}}>
                    <div style={{fontSize:32,marginBottom:12}}>🔍</div>
                    <div style={{fontSize:14,fontWeight:600,color:T.t2,marginBottom:6}}>No items match your filters</div>
                    <div style={{fontSize:12,color:T.t3}}>Try adjusting your search or clearing the active filters above</div>
                  </td>
                </tr>
              ) : filtered.map(c => {
                const isExp = expanded === c.key;
                const catColor = CAT_COLOR[c.category] || T.teal;
                return (
                  <>
                    <tr key={c.key}
                      onClick={() => setExpanded(isExp ? null : c.key)}
                      style={{cursor:"pointer",transition:"background 0.1s"}}
                      onMouseEnter={e=>e.currentTarget.style.background="#0f2236"}
                      onMouseLeave={e=>e.currentTarget.style.background=isExp?"#0f2236":"transparent"}>

                      {/* Item name */}
                      <td style={{padding:"12px 14px",borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        <div style={{display:"flex",alignItems:"center",gap:10}}>
                          <div style={{width:32,height:32,borderRadius:8,
                            background:`${catColor}18`,border:`1px solid ${catColor}30`,
                            display:"flex",alignItems:"center",justifyContent:"center",
                            fontSize:15,flexShrink:0}}>
                            {CAT_ICON[c.category]||"📦"}
                          </div>
                          <div>
                            <div style={{fontWeight:600,color:T.t1,fontSize:13}}>{c.item}</div>
                            <div style={{fontSize:10,color:T.t3,marginTop:1}}>
                              {c.orderCount} purchase{c.orderCount!==1?"s":""} · first: {c.firstDate}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Category badge */}
                      <td style={{padding:"12px 14px",borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        <Badge color={catColor}>{CAT_ICON[c.category]||"📦"} {c.category}</Badge>
                      </td>

                      {/* Vendor badges */}
                      <td style={{padding:"12px 14px",borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                          {c.vendors.slice(0,2).map(v=>(
                            <Badge key={v} color={T.teal} s={{fontSize:10}}>{v}</Badge>
                          ))}
                          {c.vendors.length>2 && <Badge color={T.t3} s={{fontSize:10}}>+{c.vendors.length-2}</Badge>}
                        </div>
                      </td>

                      {/* Last price */}
                      <td style={{padding:"12px 14px",textAlign:"right",borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        <div style={{fontWeight:700,color:T.teal,fontFamily:T.mono,fontSize:13}}>{fmt(c.lastPrice)}</div>
                        <div style={{fontSize:10,color:T.t3,marginTop:1}}>from {c.lastVendor}</div>
                      </td>

                      {/* Price trend */}
                      <td style={{padding:"12px 14px",textAlign:"right",borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        <TrendIcon trend={c.priceTrend}/>
                      </td>

                      {/* Order count */}
                      <td style={{padding:"12px 14px",textAlign:"right",fontFamily:T.mono,fontSize:12,color:T.t2,borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        {c.orderCount}
                      </td>

                      {/* Total spend */}
                      <td style={{padding:"12px 14px",textAlign:"right",fontFamily:T.mono,fontSize:13,fontWeight:700,color:T.amber,borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        {fmtK(c.totalSpend)}
                      </td>

                      {/* Last date */}
                      <td style={{padding:"12px 14px",textAlign:"right",borderBottom:isExp?"none":`1px solid ${T.border}`}}>
                        <div style={{display:"flex",alignItems:"center",justifyContent:"flex-end",gap:8}}>
                          <span style={{fontFamily:T.mono,fontSize:11,color:T.t2}}>{c.lastDate}</span>
                          <span style={{color:T.t3,fontSize:12,transition:"transform 0.2s",
                            transform:isExp?"rotate(180deg)":"rotate(0deg)"}}>▾</span>
                        </div>
                      </td>
                    </tr>

                    {/* ── Expanded Price History ── */}
                    {isExp && (
                      <tr key={`${c.key}-exp`}>
                        <td colSpan={8} style={{padding:"0 14px 14px",background:"#0a1a28",borderBottom:`1px solid ${T.border}`}}>
                          <div style={{background:"#070f1c",borderRadius:10,border:`1px solid ${T.border2}`,overflow:"hidden"}}>
                            <div style={{padding:"10px 14px",borderBottom:`1px solid ${T.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                              <div style={{fontSize:12,fontWeight:700,color:T.t1}}>📈 Price History — {c.item}</div>
                              <div style={{fontSize:11,color:T.t3}}>{c.priceHistory.length} record{c.priceHistory.length!==1?"s":""}</div>
                            </div>
                            <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
                              <thead>
                                <tr>
                                  {["Date","Vendor","Unit Price","Qty","Line Total"].map((h,i)=>(
                                    <th key={h} style={{padding:"8px 14px",textAlign:i>1?"right":"left",color:T.t3,fontWeight:600,fontSize:10,textTransform:"uppercase",letterSpacing:"0.08em",borderBottom:`1px solid ${T.border}`}}>{h}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {c.priceHistory.map((h,i)=>{
                                  const isLatest = i===0;
                                  const prevPrice = i<c.priceHistory.length-1?c.priceHistory[i+1].price:null;
                                  const change = prevPrice!==null ? h.price - prevPrice : null;
                                  return (
                                    <tr key={i} style={{background:isLatest?"#0d1e30":"transparent"}}>
                                      <td style={{padding:"8px 14px",color:T.t2,fontFamily:T.mono,fontSize:11}}>
                                        {h.date} {isLatest&&<Badge color={T.teal} s={{fontSize:9,padding:"1px 6px",marginLeft:4}}>latest</Badge>}
                                      </td>
                                      <td style={{padding:"8px 14px"}}><Badge color={T.teal} s={{fontSize:10}}>{h.vendor}</Badge></td>
                                      <td style={{padding:"8px 14px",textAlign:"right",fontFamily:T.mono,fontWeight:700,color:T.teal}}>
                                        {fmt(h.price)}
                                        {change!==null&&change!==0&&(
                                          <span style={{marginLeft:6,fontSize:10,color:change>0?T.red:T.green}}>
                                            {change>0?"↑":""}{change<0?"↓":""}{Math.abs(change).toFixed(2)}
                                          </span>
                                        )}
                                      </td>
                                      <td style={{padding:"8px 14px",textAlign:"right",color:T.t2,fontFamily:T.mono}}>{h.qty}</td>
                                      <td style={{padding:"8px 14px",textAlign:"right",color:T.amber,fontFamily:T.mono,fontWeight:600}}>{fmt(h.price*h.qty)}</td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        {filtered.length > 0 && (
          <div style={{padding:"12px 18px",borderTop:`1px solid ${T.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span style={{fontSize:11,color:T.t3}}>
              Showing {filtered.length} of {catalog.length} items
              {hasFilters?" (filtered)":""}
            </span>
            <div style={{display:"flex",gap:16,fontSize:11,color:T.t3}}>
              <span>↑ price increase &nbsp; <span style={{color:T.red}}>↑</span></span>
              <span>↓ price decrease &nbsp; <span style={{color:T.green}}>↓</span></span>
              <span>— no change &nbsp; <span style={{color:T.t3}}>—</span></span>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   PAGE: SETTINGS
══════════════════════════════════════════════════════════════════════════ */
function Settings({ profile, setProfile }) {
  const [saved,    setSaved]    = useState(false);
  const [saving,   setSaving]   = useState(false);
  const [saveErr,  setSaveErr]  = useState("");
  const [form, setForm] = useState({ ...profile });

  // Keep form in sync if profile loads async after mount
  useEffect(()=>{ setForm({...profile}); },[profile?.email]);

  const save = async ()=>{
    setSaving(true); setSaveErr("");
    const result = await Promise.resolve(setProfile(form)); // works for both sync and async setProfile
    setSaving(false);
    if (result && result.message) { setSaveErr(result.message); return; }
    setSaved(true);
    setTimeout(()=>setSaved(false),2500);
  };

  return (
    <div className="fade-up">
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:22,fontWeight:800,color:T.t1,letterSpacing:"-0.02em"}}>Settings</h1>
        <p style={{fontSize:13,color:T.t2,marginTop:3}}>Manage your profile and application preferences</p>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:20}}>
        {/* Profile */}
        <Card>
          <div style={{fontSize:14,fontWeight:700,color:T.t1,marginBottom:18}}>Profile</div>
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <div style={{display:"flex",alignItems:"center",gap:16,padding:"14px 16px",background:"#070f1c",borderRadius:12,marginBottom:6}}>
              <div style={{width:52,height:52,borderRadius:"50%",background:`linear-gradient(135deg,#f97316,#f59e0b)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,fontWeight:800,color:"#fff",flexShrink:0}}>
                {form.name?form.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase():"JD"}
              </div>
              <div>
                <div style={{fontSize:15,fontWeight:700,color:T.t1}}>{form.name||"Your Name"}</div>
                <div style={{fontSize:11,color:T.t2}}>{form.role||"Procurement Officer"}</div>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              <Input label="Full Name" value={form.name} onChange={v=>setForm(f=>({...f,name:capFirst(v)}))} placeholder="Jane Doe"/>
              <Input label="Role / Title" value={form.role} onChange={v=>setForm(f=>({...f,role:capFirst(v)}))} placeholder="Procurement Officer"/>
            </div>
            <Input label="Email" value={form.email} onChange={v=>setForm(f=>({...f,email:v}))} placeholder="jane@company.com" type="email"/>
            <Input label="Organization" value={form.org} onChange={v=>setForm(f=>({...f,org:capFirst(v)}))} placeholder="Acme Corp"/>
            <Input label="Phone" value={form.phone} onChange={v=>setForm(f=>({...f,phone:v}))} placeholder="+265 999 000"/>
          </div>
        </Card>

        {/* App Preferences */}
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          <Card>
            <div style={{fontSize:14,fontWeight:700,color:T.t1,marginBottom:16}}>App Preferences</div>
            <div style={{display:"flex",flexDirection:"column",gap:14}}>
              <Select label="Default Currency" value={form.currency||"MWK"} onChange={v=>setForm(f=>({...f,currency:v}))} opts={["MWK","USD","ZAR","KES","GHS","NGN"]}/>
              <Select label="Date Format" value={form.dateFormat||"YYYY-MM-DD"} onChange={v=>setForm(f=>({...f,dateFormat:v}))} opts={["YYYY-MM-DD","DD/MM/YYYY","MM/DD/YYYY"]}/>
              <Select label="Default Category" value={form.defaultCat||"Foods"} onChange={v=>setForm(f=>({...f,defaultCat:v}))} opts={CATEGORIES}/>
            </div>
          </Card>

          <Card>
            <div style={{fontSize:14,fontWeight:700,color:T.t1,marginBottom:16}}>Report Preferences</div>
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              <Input label="Company Name (for PDFs)" value={form.companyName||""} onChange={v=>setForm(f=>({...f,companyName:v}))} placeholder="Your Company Name"/>
              <Input label="Report Footer Note" value={form.footerNote||""} onChange={v=>setForm(f=>({...f,footerNote:v}))} placeholder="Confidential – Internal Use Only"/>
            </div>
          </Card>

          <div style={{display:"flex",gap:12,justifyContent:"flex-end"}}>
            {saveErr&&<div style={{padding:"10px 14px",background:`${T.red}15`,borderRadius:9,fontSize:12,color:T.red,border:`1px solid ${T.red}30`}}>⚠ {saveErr}</div>}
            {saved&&<div style={{padding:"10px 16px",background:`${T.teal}15`,borderRadius:9,fontSize:12,color:T.teal,border:`1px solid ${T.teal}30`,display:"flex",alignItems:"center",gap:6}}>✓ Settings saved!</div>}
            <Btn onClick={save} disabled={saving}>{saving?"Saving…":"Save Changes"}</Btn>
          </div>
        </div>
      </div>

      {/* About */}
      <Card s={{marginTop:16,padding:"16px 20px"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div>
            <div style={{fontSize:13,fontWeight:700,color:T.t1}}>ProcureDesk v2.0</div>
            <div style={{fontSize:11,color:T.t3,marginTop:2}}>Procurement management system — all data stored locally in this session</div>
          </div>
          <Badge color={T.green}>Active</Badge>
        </div>
      </Card>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   ROOT APP
══════════════════════════════════════════════════════════════════════════ */
function AppLegacy() {
  const [page, setPage] = useState("home");
  const [purchases, setPurchases] = useState(INITIAL_PURCHASES);
  const [vendors, setVendors] = useState(INITIAL_VENDORS);
  const [profile, setProfile] = useState({ name:"Jane Doe", role:"Procurement Officer", email:"jane@company.mw", org:"Acme Corp", phone:"+265 999 000", currency:"MWK", dateFormat:"YYYY-MM-DD", defaultCat:"Foods" });
  const [newPurchaseOpen, setNewPurchaseOpen] = useState(false);
  const [addVendorOpen,   setAddVendorOpen]   = useState(false);

  const NAV = [
    { id:"home",      icon:"🏠", label:"Home" },
    { id:"purchases", icon:"🛒", label:"Purchases", badge:purchases.length },
    { id:"vendors",   icon:"🏭", label:"Vendors" },
    { id:"insights",  icon:"📊", label:"Insights" },
    { id:"reports",   icon:"📋", label:"Reports" },
    { id:"catalog",   icon:"📖", label:"Catalog" },
  ];

  return (
    <div style={{ display:"flex", height:"100vh", background:T.mainBg, fontFamily:"'Sora', sans-serif", overflow:"hidden" }}>
      <GS />

      {/* ── Sidebar ── */}
      <div style={{ width:210, background:T.sidebar, display:"flex", flexDirection:"column", flexShrink:0, borderRight:`1px solid ${T.border}` }}>
        {/* User */}
        <div style={{ padding:"18px 14px 14px", borderBottom:`1px solid ${T.border}` }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:38, height:38, borderRadius:"50%", background:"linear-gradient(135deg,#f97316,#f59e0b)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, fontWeight:800, color:"#fff", flexShrink:0 }}>
              {profile.name.split(" ").map(w=>w[0]).join("").slice(0,2)}
            </div>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:13, fontWeight:700, color:T.t1, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{profile.name}</div>
              <div style={{ fontSize:10, color:T.t3 }}>{profile.role}</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <div style={{ flex:1, padding:"10px 8px", display:"flex", flexDirection:"column", gap:2, overflowY:"auto" }}>
          {NAV.map(n=><NavItem key={n.id} icon={n.icon} label={n.label} active={page===n.id} onClick={()=>setPage(n.id)} badge={n.badge}/>)}
        </div>

        {/* Bottom: Settings */}
        <div style={{ padding:"10px 8px 14px", borderTop:`1px solid ${T.border}` }}>
          <NavItem icon="⚙️" label="Settings" active={page==="settings"} onClick={()=>setPage("settings")}/>
        </div>
      </div>

      {/* ── Main Content ── */}
      <div style={{ flex:1, overflowY:"auto", padding:"28px 28px" }}>
        {page==="home"      && <Home purchases={purchases} vendors={vendors} go={setPage} openNewPurchase={()=>{setPage("purchases");setNewPurchaseOpen(true);}} openAddVendor={()=>{setPage("vendors");setAddVendorOpen(true);}}/>}
        {page==="purchases" && <Purchases purchases={purchases} setPurchases={setPurchases} vendors={vendors} modalOpen={newPurchaseOpen} setModalOpen={setNewPurchaseOpen}/>}
        {page==="vendors"   && <Vendors vendors={vendors} setVendors={setVendors} purchases={purchases} setPurchases={setPurchases} triggerAdd={addVendorOpen} clearTriggerAdd={()=>setAddVendorOpen(false)}/>}
        {page==="insights"  && <Insights purchases={purchases}/>}
        {page==="reports"   && <Reports purchases={purchases} vendors={vendors}/>}
        {page==="catalog"   && <Catalog purchases={purchases}/>}
        {page==="settings"  && <Settings profile={profile} setProfile={setProfile}/>}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   AUTH SCREEN  (shown when no session)
══════════════════════════════════════════════════════════════════════════ */
function AuthScreen({ onGuest }) {
  const [mode,    setMode]    = useState("login");   // "login" | "signup" | "magic"
  const [email,   setEmail]   = useState("");
  const [pass,    setPass]    = useState("");
  const [name,    setName]    = useState("");
  const [loading, setLoading] = useState(false);
  const [msg,     setMsg]     = useState({ type:"", text:"" });

  const flash = (type, text) => { setMsg({type, text}); setTimeout(()=>setMsg({type:"",text:""}), 5000); };

  const handleLogin = async () => {
    if (!email || !pass) { flash("error","Please enter your email and password."); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password: pass });
    setLoading(false);
    if (error) flash("error", error.message);
  };

  const handleSignup = async () => {
    if (!name.trim()) { flash("error","Please enter your full name."); return; }
    if (!email)       { flash("error","Please enter your email."); return; }
    if (pass.length < 6) { flash("error","Password must be at least 6 characters."); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email, password: pass,
      options: { data: { full_name: name.trim() } }
    });
    setLoading(false);
    if (error) flash("error", error.message);
    else flash("success","Account created! Check your email to confirm, then log in.");
  };

  const handleMagicLink = async () => {
    if (!email) { flash("error","Please enter your email address."); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({ email });
    setLoading(false);
    if (error) flash("error", error.message);
    else flash("success","Magic link sent! Check your inbox.");
  };

  const inputStyle = {
    background:"#070f1c", border:`1.5px solid ${T.border}`, borderRadius:10,
    padding:"12px 14px", color:T.t1, fontSize:14, outline:"none", width:"100%",
    transition:"border-color 0.2s, box-shadow 0.2s",
  };
  const focusStyle = e => { e.target.style.borderColor=T.teal; e.target.style.boxShadow=`0 0 0 3px ${T.tealGlow}`; };
  const blurStyle  = e => { e.target.style.borderColor=T.border; e.target.style.boxShadow="none"; };

  return (
    <div style={{ minHeight:"100vh", background:T.mainBg, display:"flex", alignItems:"center",
      justifyContent:"center", fontFamily:"'Sora',sans-serif", padding:20 }}>
      <GS/>

      {/* Background glow */}
      <div style={{ position:"fixed", inset:0, pointerEvents:"none", overflow:"hidden" }}>
        <div style={{ position:"absolute", top:"-20%", left:"-10%", width:600, height:600,
          background:`radial-gradient(circle, ${T.tealGlow} 0%, transparent 70%)`, borderRadius:"50%" }}/>
        <div style={{ position:"absolute", bottom:"-20%", right:"-10%", width:500, height:500,
          background:`radial-gradient(circle, ${T.purpleGlow} 0%, transparent 70%)`, borderRadius:"50%" }}/>
      </div>

      <div className="fade-up" style={{ width:"100%", maxWidth:420, position:"relative", zIndex:1 }}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:32 }}>
          <div style={{ width:56, height:56, borderRadius:16, background:`linear-gradient(135deg,${T.teal},${T.purple})`,
            display:"inline-flex", alignItems:"center", justifyContent:"center", fontSize:26, marginBottom:14 }}>🛒</div>
          <div style={{ fontSize:24, fontWeight:800, color:T.t1, letterSpacing:"-0.02em", marginBottom:4 }}>ProcureDesk</div>
          <div style={{ fontSize:13, color:T.t3 }}>Procurement management system</div>
        </div>

        {/* Card */}
        <div style={{ background:T.cardBg, border:`1px solid ${T.border2}`, borderRadius:20, padding:32 }}>
          {/* Tab switcher */}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:4,
            background:"#070f1c", borderRadius:10, padding:4, marginBottom:24 }}>
            {[["login","Sign In"],["signup","Sign Up"],["magic","Magic Link"]].map(([m,lbl])=>(
              <button key={m} onClick={()=>{setMode(m);setMsg({type:"",text:""}); }}
                style={{ border:"none", borderRadius:8, padding:"8px 4px", fontSize:12, fontWeight:600,
                  cursor:"pointer", transition:"all 0.15s",
                  background: mode===m ? T.teal : "transparent",
                  color: mode===m ? "#fff" : T.t3 }}>
                {lbl}
              </button>
            ))}
          </div>

          <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
            {/* Name (signup only) */}
            {mode==="signup" && (
              <div>
                <label style={{ fontSize:10, fontWeight:700, color:T.t2, textTransform:"uppercase", letterSpacing:"0.1em", display:"block", marginBottom:5 }}>Full Name</label>
                <input value={name} onChange={e=>setName(capFirst(e.target.value))} placeholder="Jane Doe"
                  style={inputStyle} onFocus={focusStyle} onBlur={blurStyle}/>
              </div>
            )}

            {/* Email */}
            <div>
              <label style={{ fontSize:10, fontWeight:700, color:T.t2, textTransform:"uppercase", letterSpacing:"0.1em", display:"block", marginBottom:5 }}>Email</label>
              <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"
                style={inputStyle} onFocus={focusStyle} onBlur={blurStyle}/>
            </div>

            {/* Password (login + signup only) */}
            {(mode==="login"||mode==="signup") && (
              <div>
                <label style={{ fontSize:10, fontWeight:700, color:T.t2, textTransform:"uppercase", letterSpacing:"0.1em", display:"block", marginBottom:5 }}>Password</label>
                <input type="password" value={pass} onChange={e=>setPass(e.target.value)}
                  placeholder={mode==="signup"?"Min. 6 characters":"••••••••"}
                  style={inputStyle} onFocus={focusStyle} onBlur={blurStyle}
                  onKeyDown={e=>e.key==="Enter"&&(mode==="login"?handleLogin():handleSignup())}/>
              </div>
            )}

            {/* Flash message */}
            {msg.text && (
              <div style={{ padding:"10px 14px", borderRadius:9, fontSize:12,
                background: msg.type==="error" ? `${T.red}18` : `${T.teal}18`,
                color: msg.type==="error" ? T.red : T.teal,
                border: `1px solid ${msg.type==="error" ? T.red : T.teal}30` }}>
                {msg.type==="error" ? "⚠ " : "✓ "}{msg.text}
              </div>
            )}

            {/* CTA button */}
            <button onClick={mode==="login"?handleLogin:mode==="signup"?handleSignup:handleMagicLink}
              disabled={loading}
              style={{ border:"none", borderRadius:10, padding:"13px", fontSize:14, fontWeight:700,
                cursor:loading?"not-allowed":"pointer", background:`linear-gradient(135deg,${T.teal},${T.tealDim})`,
                color:"#fff", display:"flex", alignItems:"center", justifyContent:"center", gap:8,
                opacity:loading?0.7:1, transition:"opacity 0.2s", marginTop:2 }}>
              {loading
                ? <><span className="spin" style={{width:16,height:16,border:`2px solid #fff4`,borderTopColor:"#fff",borderRadius:"50%",display:"inline-block"}}/>Processing…</>
                : mode==="login" ? "Sign In →" : mode==="signup" ? "Create Account →" : "Send Magic Link →"
              }
            </button>
          </div>
        </div>

        {/* Guest access */}
        <div style={{ textAlign:"center", marginTop:20 }}>
          <span style={{ fontSize:12, color:T.t3 }}>Just browsing? </span>
          <button onClick={onGuest}
            style={{ background:"none", border:"none", color:T.teal, fontSize:12, fontWeight:600, cursor:"pointer",
              textDecoration:"underline", textUnderlineOffset:3 }}>
            View Catalog as Guest →
          </button>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   GUEST CATALOG WRAPPER  (read-only Catalog + login banner)
══════════════════════════════════════════════════════════════════════════ */
function GuestCatalogView({ onLogin }) {
  const [purchases, setPurchases] = useState([]);
  const [loading,   setLoading]   = useState(true);

  // Fetch all purchases — guests see a shared read-only view
  // (requires a Supabase policy that allows select with no auth, or a public view)
  // For simplicity we fetch without auth; RLS will return empty if not configured for public.
  // To allow guests to see catalog data, add this policy in Supabase:
  //   CREATE POLICY "Public read purchases" ON purchases FOR SELECT USING (true);
  useEffect(()=>{
    supabase.from("purchases").select("*").order("date", { ascending:false })
      .then(({ data }) => { if(data) setPurchases(data.map(r=>({...r, price:Number(r.price), qty:Number(r.qty)}))); setLoading(false); });
  },[]);

  return (
    <div style={{ minHeight:"100vh", background:T.mainBg, fontFamily:"'Sora',sans-serif" }}>
      <GS/>
      {/* Login banner */}
      <div style={{ background:`linear-gradient(90deg,${T.teal}18,${T.purple}18)`,
        borderBottom:`1px solid ${T.border}`, padding:"12px 28px",
        display:"flex", alignItems:"center", justifyContent:"space-between", gap:16, flexWrap:"wrap" }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <span style={{ fontSize:16 }}>👋</span>
          <span style={{ fontSize:13, color:T.t2 }}>
            You're viewing as a <strong style={{color:T.t1}}>guest</strong> — catalog is read-only.
          </span>
        </div>
        <button onClick={onLogin}
          style={{ border:"none", borderRadius:9, padding:"8px 18px", fontSize:12, fontWeight:700,
            background:`linear-gradient(135deg,${T.teal},${T.tealDim})`, color:"#fff", cursor:"pointer" }}>
          Sign In / Sign Up →
        </button>
      </div>
      <div style={{ padding:"28px 28px" }}>
        {loading
          ? <div style={{textAlign:"center",padding:"80px",color:T.t3}}>Loading catalog…</div>
          : <Catalog purchases={purchases} readOnly/>}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════
   ROOT APP  (Supabase-powered)
══════════════════════════════════════════════════════════════════════════ */
export default function App() {
  const [session,  setSession]  = useState(undefined); // undefined = loading, null = no session
  const [guest,    setGuest]    = useState(false);
  const [page,     setPage]     = useState("home");

  // ── Data state (replaces INITIAL_PURCHASES / INITIAL_VENDORS) ──
  const [purchases,    setPurchases]    = useState([]);
  const [vendors,      setVendors]      = useState([]);
  const [profile,      setProfileState] = useState(null);
  const [dataLoading,  setDataLoading]  = useState(false);

  const [newPurchaseOpen, setNewPurchaseOpen] = useState(false);
  const [addVendorOpen,   setAddVendorOpen]   = useState(false);

  // ── Auth listener ──
  useEffect(()=>{
    supabase.auth.getSession().then(({ data:{ session } })=> setSession(session));
    const { data:{ subscription } } = supabase.auth.onAuthStateChange((_event, session)=>{
      setSession(session);
      if (!session) { setPurchases([]); setVendors([]); setProfileState(null); }
    });
    return ()=> subscription.unsubscribe();
  },[]);

  // ── Load data when session exists ──
  const loadAll = useCallback(async ()=>{
    if (!session) return;
    setDataLoading(true);
    const uid = session.user.id;

    const [{ data:pData }, { data:vData }, { data:prData }] = await Promise.all([
      supabase.from("purchases").select("*").eq("user_id", uid).order("date", { ascending:false }),
      supabase.from("vendors").select("*").eq("user_id", uid).order("name"),
      supabase.from("profiles").select("*").eq("id", uid).single(),
    ]);

    if (pData) setPurchases(pData.map(r=>({ ...r, price:Number(r.price), qty:Number(r.qty) })));
    if (vData) setVendors(vData);
    if (prData) setProfileState({
      name:      prData.full_name    || session.user.email,
      role:      prData.role         || "Procurement Officer",
      email:     session.user.email,
      org:       prData.organization || "",
      phone:     prData.phone        || "",
      currency:  prData.currency     || "MWK",
      dateFormat:prData.date_format  || "YYYY-MM-DD",
      defaultCat:prData.default_cat  || "Foods",
      companyName:prData.company_name|| "",
      footerNote: prData.footer_note || "",
    });
    setDataLoading(false);
  },[session]);

  useEffect(()=>{ loadAll(); },[loadAll]);

  // ── Supabase CRUD wrappers ──
  const addPurchase = useCallback(async (p)=>{
    const row = { user_id:session.user.id, vendor:p.vendor, item:p.item,
      qty:p.qty, price:p.price, category:p.category, date:p.date };
    const { data, error } = await supabase.from("purchases").insert(row).select().single();
    if (!error && data) setPurchases(prev=>[{...data,price:Number(data.price),qty:Number(data.qty)},...prev]);
    return error;
  },[session]);

  const deletePurchase = useCallback(async (id)=>{
    await supabase.from("purchases").delete().eq("id",id);
    setPurchases(prev=>prev.filter(x=>x.id!==id));
  },[]);

  const addVendorDB = useCallback(async (v)=>{
    const row = { user_id:session.user.id, ...v };
    const { data, error } = await supabase.from("vendors").insert(row).select().single();
    if (!error && data) setVendors(prev=>[...prev,data].sort((a,b)=>a.name.localeCompare(b.name)));
    return error;
  },[session]);

  const deleteVendorDB = useCallback(async (id)=>{
    await supabase.from("vendors").delete().eq("id",id);
    setVendors(prev=>prev.filter(x=>x.id!==id));
  },[]);

  const saveProfile = useCallback(async (updates)=>{
    const row = {
      full_name:    updates.name,
      role:         updates.role,
      organization: updates.org,
      phone:        updates.phone,
      currency:     updates.currency,
      date_format:  updates.dateFormat,
      default_cat:  updates.defaultCat,
      company_name: updates.companyName || "",
      footer_note:  updates.footerNote  || "",
    };
    const { error } = await supabase.from("profiles").update(row).eq("id", session.user.id);
    if (!error) setProfileState(updates);
    return error;
  },[session]);

  const signOut = async () => {
    await supabase.auth.signOut();
    setGuest(false);
    setPage("home");
  };

  // ── Render states ──

  // Still checking auth
  if (session === undefined) return (
    <div style={{ height:"100vh", display:"flex", alignItems:"center", justifyContent:"center", background:T.mainBg }}>
      <GS/>
      <div style={{ textAlign:"center", color:T.t3 }}>
        <div className="spin" style={{ width:36, height:36, border:`3px solid ${T.border}`, borderTopColor:T.teal,
          borderRadius:"50%", margin:"0 auto 14px" }}/>
        <div style={{ fontSize:13 }}>Loading…</div>
      </div>
    </div>
  );

  // No session — show auth or guest catalog
  if (!session) {
    if (guest) return <GuestCatalogView onLogin={()=>setGuest(false)}/>;
    return <AuthScreen onGuest={()=>setGuest(true)}/>;
  }

  // Waiting for data
  const prof = profile || { name: session.user.email, role:"", email:session.user.email, org:"", phone:"", currency:"MWK", dateFormat:"YYYY-MM-DD", defaultCat:"Foods", companyName:"", footerNote:"" };

  const NAV = [
    { id:"home",      icon:"🏠", label:"Home" },
    { id:"purchases", icon:"🛒", label:"Purchases", badge:purchases.length||undefined },
    { id:"vendors",   icon:"🏭", label:"Vendors" },
    { id:"insights",  icon:"📊", label:"Insights" },
    { id:"reports",   icon:"📋", label:"Reports" },
    { id:"catalog",   icon:"📖", label:"Catalog" },
  ];

  return (
    <div style={{ display:"flex", height:"100vh", background:T.mainBg, fontFamily:"'Sora', sans-serif", overflow:"hidden" }}>
      <GS />

      {/* ── Sidebar ── */}
      <div style={{ width:210, background:T.sidebar, display:"flex", flexDirection:"column", flexShrink:0, borderRight:`1px solid ${T.border}` }}>
        {/* User */}
        <div style={{ padding:"18px 14px 14px", borderBottom:`1px solid ${T.border}` }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <div style={{ width:38, height:38, borderRadius:"50%", background:"linear-gradient(135deg,#f97316,#f59e0b)",
              display:"flex", alignItems:"center", justifyContent:"center", fontSize:14, fontWeight:800, color:"#fff", flexShrink:0 }}>
              {prof.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase()}
            </div>
            <div style={{ minWidth:0 }}>
              <div style={{ fontSize:13, fontWeight:700, color:T.t1, whiteSpace:"nowrap", overflow:"hidden", textOverflow:"ellipsis" }}>{prof.name}</div>
              <div style={{ fontSize:10, color:T.t3 }}>{prof.role||"Procurement Officer"}</div>
            </div>
          </div>
        </div>

        {/* Nav */}
        <div style={{ flex:1, padding:"10px 8px", display:"flex", flexDirection:"column", gap:2, overflowY:"auto" }}>
          {NAV.map(n=><NavItem key={n.id} icon={n.icon} label={n.label} active={page===n.id} onClick={()=>setPage(n.id)} badge={n.badge}/>)}
        </div>

        {/* Bottom */}
        <div style={{ padding:"10px 8px 14px", borderTop:`1px solid ${T.border}`, display:"flex", flexDirection:"column", gap:2 }}>
          <NavItem icon="⚙️" label="Settings" active={page==="settings"} onClick={()=>setPage("settings")}/>
          <NavItem icon="🚪" label="Sign Out" active={false} onClick={signOut}/>
        </div>
      </div>

      {/* ── Main Content ── */}
      <div style={{ flex:1, overflowY:"auto", padding:"28px 28px", position:"relative" }}>
        {/* Data loading overlay */}
        {dataLoading && (
          <div style={{ position:"absolute", top:16, right:24, display:"flex", alignItems:"center", gap:8,
            background:T.cardBg, border:`1px solid ${T.border}`, borderRadius:8, padding:"6px 12px", zIndex:10 }}>
            <div className="spin" style={{ width:12, height:12, border:`2px solid ${T.border}`,
              borderTopColor:T.teal, borderRadius:"50%" }}/>
            <span style={{ fontSize:11, color:T.t2 }}>Syncing…</span>
          </div>
        )}

        {page==="home"      && <Home purchases={purchases} vendors={vendors} go={setPage}
            openNewPurchase={()=>{ setPage("purchases"); setNewPurchaseOpen(true); }}
            openAddVendor={()=>{ setPage("vendors"); setAddVendorOpen(true); }}/>}
        {page==="purchases" && <Purchases purchases={purchases} setPurchases={setPurchases}
            vendors={vendors}
            modalOpen={newPurchaseOpen} setModalOpen={setNewPurchaseOpen}
            addPurchaseDB={addPurchase} deletePurchaseDB={deletePurchase}/>}
        {page==="vendors"   && <Vendors vendors={vendors} setVendors={setVendors}
            purchases={purchases} setPurchases={setPurchases}
            addVendorDB={addVendorDB} deleteVendorDB={deleteVendorDB}
            triggerAdd={addVendorOpen} clearTriggerAdd={()=>setAddVendorOpen(false)}/>}
        {page==="insights"  && <Insights purchases={purchases}/>}
        {page==="reports"   && <Reports purchases={purchases} vendors={vendors}/>}
        {page==="catalog"   && <Catalog purchases={purchases}/>}
        {page==="settings"  && <Settings profile={prof} setProfile={saveProfile}/>}
      </div>
    </div>
  );
}
