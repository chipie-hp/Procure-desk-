-- ============================================================
--  ProcureDesk — Supabase Schema
--  Run this entire file in your Supabase SQL Editor
--  (Dashboard → SQL Editor → New Query → Paste → Run)
-- ============================================================

-- ── 1. PROFILES ─────────────────────────────────────────────
-- Extends Supabase's built-in auth.users table
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  full_name    text not null default '',
  role         text not null default 'Procurement Officer',
  organization text not null default '',
  phone        text not null default '',
  currency     text not null default 'MWK',
  date_format  text not null default 'YYYY-MM-DD',
  default_cat  text not null default 'Foods',
  company_name text not null default '',
  footer_note  text not null default '',
  created_at   timestamptz default now()
);

-- Auto-create a profile row whenever a new user signs up
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- ── 2. VENDORS ──────────────────────────────────────────────
create table if not exists public.vendors (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  name       text not null,
  category   text not null default 'Other',
  contact    text not null default '',
  phone      text not null default '',
  address    text not null default '',
  created_at timestamptz default now()
);

create index if not exists vendors_user_id_idx on public.vendors(user_id);


-- ── 3. PURCHASES ────────────────────────────────────────────
create table if not exists public.purchases (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  vendor     text not null,
  item       text not null,
  qty        numeric not null default 1,
  price      numeric not null default 0,
  category   text not null default 'Other',
  date       date not null default current_date,
  created_at timestamptz default now()
);

create index if not exists purchases_user_id_idx on public.purchases(user_id);
create index if not exists purchases_date_idx    on public.purchases(date desc);


-- ============================================================
--  ROW LEVEL SECURITY (RLS)
--  Each user can only read/write their own rows.
-- ============================================================

-- profiles
alter table public.profiles enable row level security;

create policy "Users can view own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update own profile"
  on public.profiles for update
  using (auth.uid() = id);


-- vendors
alter table public.vendors enable row level security;

create policy "Users can view own vendors"
  on public.vendors for select
  using (auth.uid() = user_id);

create policy "Users can insert own vendors"
  on public.vendors for insert
  with check (auth.uid() = user_id);

create policy "Users can update own vendors"
  on public.vendors for update
  using (auth.uid() = user_id);

create policy "Users can delete own vendors"
  on public.vendors for delete
  using (auth.uid() = user_id);


-- purchases
alter table public.purchases enable row level security;

create policy "Users can view own purchases"
  on public.purchases for select
  using (auth.uid() = user_id);

create policy "Users can insert own purchases"
  on public.purchases for insert
  with check (auth.uid() = user_id);

create policy "Users can update own purchases"
  on public.purchases for update
  using (auth.uid() = user_id);

create policy "Users can delete own purchases"
  on public.purchases for delete
  using (auth.uid() = user_id);


-- ============================================================
--  DONE — your schema is ready.
--  Next step: grab your Project URL and anon key from
--  Supabase Dashboard → Settings → API
--  and paste them into supabase.js
-- ============================================================
